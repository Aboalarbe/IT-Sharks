package aboalarbe.app.com.itsharks.Data;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * Created by mohamed_aboalarbe on 5/13/2017.
 */

public class DataProvider extends ContentProvider {

    private static final UriMatcher URI_MATCHER = buildUriMatcher();
    private DbHelper dbHelper;

    private static final int COURSE = 201;
    private static final int INSTRUCTOR = 203;
    private static final int REVIEW = 205;

    private static UriMatcher buildUriMatcher() {
        UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
        String authority = Contract.AUTHORITY;
        matcher.addURI(authority, Contract.CourseTable.TABLE_NAME, COURSE);
        matcher.addURI(authority, Contract.InstructorTable.TABLE_NAME, INSTRUCTOR);
        matcher.addURI(authority, Contract.ReviewTable.TABLE_NAME, REVIEW);
        return matcher;
    }

    @Override
    public boolean onCreate() {
        dbHelper = new DbHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        Cursor retCursor;
        String tableName;
        switch (URI_MATCHER.match(uri)) {
            case COURSE: {
                tableName = Contract.CourseTable.TABLE_NAME;
                break;
            }
            case INSTRUCTOR: {
                tableName = Contract.InstructorTable.TABLE_NAME;
                break;
            }
            case REVIEW: {
                tableName = Contract.ReviewTable.TABLE_NAME;
                break;
            }
            default: {
                throw new UnsupportedOperationException("Unknown Uri : " + uri);
            }
        }
        retCursor = dbHelper.getReadableDatabase().query(
                tableName,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder
        );
        return retCursor;
    }

    @Override
    public int bulkInsert(@NonNull Uri uri, @NonNull ContentValues[] values) {
        String tableName;
        int numberOfInserted;
        switch (URI_MATCHER.match(uri)) {
            case COURSE: {
                tableName = Contract.CourseTable.TABLE_NAME;
                break;
            }
            case INSTRUCTOR: {
                tableName = Contract.InstructorTable.TABLE_NAME;
                break;
            }
            case REVIEW: {
                tableName = Contract.ReviewTable.TABLE_NAME;
                break;
            }
            default:
                return super.bulkInsert(uri, values);
        }
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        db.execSQL("delete from " + tableName);
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" + tableName + "'");
        try {
            for (ContentValues value : values) {
                long _id = db.insertOrThrow(tableName, null, value);
                if (_id <= 0) {
                    throw new SQLException("Failed To insert row : " + uri);
                }
            }
            db.setTransactionSuccessful();
            getContext().getContentResolver().notifyChange(uri, null);
            numberOfInserted = values.length;
        } finally {
            db.endTransaction();
        }
        return numberOfInserted;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
