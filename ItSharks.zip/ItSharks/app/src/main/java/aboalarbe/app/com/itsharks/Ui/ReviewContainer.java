package aboalarbe.app.com.itsharks.Ui;

import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import aboalarbe.app.com.itsharks.Adapters.ReviewAdapter;
import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.UtilitiesClass;
import butterknife.BindView;
import butterknife.ButterKnife;

public class ReviewContainer extends AppCompatActivity {

    @BindView(R.id.tab_layout)
    TabLayout tabLayout;
    @BindView(R.id.view_pager)
    ViewPager viewPager;
    @BindView(R.id.adView)
    AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_container);
        ButterKnife.bind(this);
        if (UtilitiesClass.isConnected(this)) {
            loadAds();
        }
        tabLayout.addTab(tabLayout.newTab()
                .setText(getString(R.string.add_review)).setIcon(R.drawable.addreview));
        tabLayout.addTab(tabLayout.newTab()
                .setText(getString(R.string.display_review)).setIcon(R.drawable.info));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        ReviewAdapter adapter = new ReviewAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition(), true);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    /*
    this method which i load the Ads
     */
    private void loadAds() {
        new AsyncTask<Void, Void, AdRequest>() {
            @Override
            protected AdRequest doInBackground(Void... params) {
                MobileAds.initialize(getApplicationContext(), getString(R.string.banner_ad_unit_id));
                AdRequest adRequest = new AdRequest.Builder().build();
                return adRequest;
            }

            @Override
            protected void onPostExecute(AdRequest request) {
                super.onPostExecute(request);
                mAdView.loadAd(request);
            }
        }.execute();
    }
}