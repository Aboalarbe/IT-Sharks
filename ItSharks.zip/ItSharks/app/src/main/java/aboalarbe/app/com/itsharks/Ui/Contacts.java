package aboalarbe.app.com.itsharks.Ui;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.UtilitiesClass;
import butterknife.BindView;
import butterknife.ButterKnife;

public class Contacts extends AppCompatActivity {

    @BindView(R.id.facebook)
    ImageButton facebook;
    @BindView(R.id.google)
    ImageButton google;
    @BindView(R.id.linkedin)
    ImageButton linkedin;
    @BindView(R.id.web)
    ImageButton website;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
        ButterKnife.bind(this);

        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(getString(R.string.facebook_url));
                UtilitiesClass.startActionViewIntent(Contacts.this, uri);
            }
        });

        google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(getString(R.string.google_plus_url));
                UtilitiesClass.startActionViewIntent(Contacts.this, uri);
            }
        });

        linkedin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Contacts.this, getString(R.string.linkedin_url), Toast.LENGTH_SHORT).show();
            }
        });

        website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(getString(R.string.itsharks_website));
                UtilitiesClass.startActionViewIntent(Contacts.this, uri);
            }
        });
    }
}
