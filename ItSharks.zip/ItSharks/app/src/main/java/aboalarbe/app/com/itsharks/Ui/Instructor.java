package aboalarbe.app.com.itsharks.Ui;

import android.database.Cursor;
import android.os.PersistableBundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import aboalarbe.app.com.itsharks.Adapters.InstructorListAdapter;
import aboalarbe.app.com.itsharks.Data.Contract;
import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.InstructorObject;
import butterknife.BindView;
import butterknife.ButterKnife;

public class Instructor extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    @BindView(R.id.list_view)
    ListView listView;
    private ArrayList<InstructorObject> list;
    private InstructorListAdapter adapter;
    private static final int LOADER_ID = 21;
    private int scrollIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor);
        ButterKnife.bind(this);
        getSupportLoaderManager().initLoader(LOADER_ID, null, this);
        if (savedInstanceState == null ||
                !savedInstanceState.containsKey(getString(R.string.instructor_list_key))
                        && !savedInstanceState.containsKey(getString(R.string.instructor_scroll))) {
            list = new ArrayList<InstructorObject>();
            scrollIndex = 0;
        } else {
            list = savedInstanceState.getParcelableArrayList(getString(R.string.instructor_list_key));
            scrollIndex = savedInstanceState.getInt(getString(R.string.instructor_scroll));
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        scrollIndex = listView.getFirstVisiblePosition();
        outState.putParcelableArrayList(getString(R.string.instructor_list_key), list);
        outState.putInt(getString(R.string.instructor_scroll), scrollIndex);
        super.onSaveInstanceState(outState, outPersistentState);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader<Cursor>(this) {
            Cursor retCursor = null;

            @Override
            protected void onStartLoading() {
                if (retCursor != null) {
                    deliverResult(retCursor);
                } else {
                    forceLoad();
                }
            }

            @Override
            public Cursor loadInBackground() {
                try {
                    return getContentResolver().query(
                            Contract.InstructorTable.CONTENT_URI,
                            null,
                            null,
                            null,
                            null
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public void deliverResult(Cursor data) {
                retCursor = data;
                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null) {
            list.clear();
            if (data.moveToFirst()) {
                do {
                    String instructorName = data.getString(data.getColumnIndex(Contract.InstructorTable.NAME));
                    String instructorCourse = data.getString(data.getColumnIndex(Contract.InstructorTable.COURSE));
                    int instructorImage = data.getInt(data.getColumnIndex(Contract.InstructorTable.IMAGE));
                    list.add(new InstructorObject(instructorName, instructorCourse, instructorImage));
                } while (data.moveToNext());
            }
        }
        adapter = new InstructorListAdapter(this, list);
        listView.setAdapter(adapter);
        listView.smoothScrollToPosition(scrollIndex);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }
}
