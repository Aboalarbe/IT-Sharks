package aboalarbe.app.com.itsharks.Ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.Authentication;
import aboalarbe.app.com.itsharks.Utilities.UtilitiesClass;
import butterknife.BindView;
import butterknife.ButterKnife;

public class CourseRegistrationForm extends AppCompatActivity {

    @BindView(R.id.first_name)
    EditText firsrName;
    @BindView(R.id.last_name)
    EditText lastName;
    @BindView(R.id.phone_number)
    EditText phone_number;
    @BindView(R.id.email)
    EditText email;
    @BindView(R.id.facebook)
    EditText facebook;
    @BindView(R.id.submit)
    Button submit;
    @BindView(R.id.progress_bar)
    ProgressBar bar;

    String courseName = CourseDetailsContainerFragment.dataObject.getCourseName();
    String firstName_str, lastName_str, phoneNumber_str, email_str, facebook_str;
    FirebaseAuth auth = FirebaseAuth.getInstance();
    FirebaseUser user = auth.getCurrentUser();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_registration_form);
        ButterKnife.bind(this);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag = getInputData();
                if (flag) {
                    if (UtilitiesClass.isConnected(CourseRegistrationForm.this)) {
                        bar.setVisibility(View.VISIBLE);
                        sendStudentDataToServer();
                    } else {
                        Toast.makeText(CourseRegistrationForm.this, getString(R.string.check_connection), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(CourseRegistrationForm.this, getString(R.string.input_error), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Authentication.isAlreadySigned(auth)) {
            email.setText(user.getEmail());
        }
    }

    /*
        this method that get the data from the user and check if empty
         */
    private boolean getInputData() {
        firstName_str = firsrName.getText().toString();
        lastName_str = lastName.getText().toString();
        phoneNumber_str = phone_number.getText().toString();
        email_str = email.getText().toString();
        facebook_str = facebook.getText().toString();
        if (firstName_str.isEmpty() || lastName_str.isEmpty() || phoneNumber_str.isEmpty() || email_str.isEmpty())

            return false;

        else
            return true;
    }

    /*
    this method send the data that user entered to the backend server

     */
    private void sendStudentDataToServer() {
        String serverUrl = getString(R.string.server_url);
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.POST, serverUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    String result = object.getString(getString(R.string.response));
                    if (result.equalsIgnoreCase(getString(R.string.done))) {
                        bar.setVisibility(View.GONE);
                        Toast.makeText(CourseRegistrationForm.this, getString(R.string.review_done), Toast.LENGTH_LONG).show();
                        finish();
                    } else {
                        bar.setVisibility(View.GONE);
                        Toast.makeText(CourseRegistrationForm.this, getString(R.string.review_error), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                bar.setVisibility(View.GONE);
                Toast.makeText(CourseRegistrationForm.this, getString(R.string.unexcepected_error), Toast.LENGTH_SHORT).show();
            }
        }) {
            /*
            send data parameters to the server
             */
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put(getString(R.string.first_name_key), firstName_str);
                map.put(getString(R.string.last_name_key), lastName_str);
                map.put(getString(R.string.phone_number_key), phoneNumber_str);
                map.put(getString(R.string.email_key), email_str);
                map.put(getString(R.string.facebook_key), facebook_str);
                map.put(getString(R.string.course_name_key), courseName);
                return map;
            }
        };
        queue.add(request);
    }
}
