package aboalarbe.app.com.itsharks.Ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.SpannableString;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import aboalarbe.app.com.itsharks.Utilities.Authentication;
import aboalarbe.app.com.itsharks.Utilities.CourseObject;
import aboalarbe.app.com.itsharks.Utilities.DataListener;
import aboalarbe.app.com.itsharks.Utilities.UtilitiesClass;
import butterknife.BindView;
import butterknife.ButterKnife;


import aboalarbe.app.com.itsharks.R;

public class Course extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, DataListener {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.drawer_layout)
    DrawerLayout drawer;
    @BindView(R.id.nav_view)
    NavigationView navigationView;

    FirebaseAuth auth = FirebaseAuth.getInstance();
    private static final int RC_SIGN_IN = 114;
    private boolean isTwoPane = false;
    CourseFragment courseFragment = new CourseFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);
        ButterKnife.bind(this);

        if (findViewById(R.id.details_container) != null) {
            isTwoPane = true;
        }

        // check if user is signed or no
        if (Authentication.isAlreadySigned(auth)) {
            //do no thing
        } else {
            //if he not signed start Ui flow to sign in with different providers
            if (UtilitiesClass.isConnected(this)) {
                Authentication.startSigninUiFlow(this, RC_SIGN_IN);
            } else {
                startActivity(new Intent(Course.this, NoConnection.class));
            }
        }

        if (savedInstanceState == null) {
            courseFragment.setDataListener(this);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.course_container, courseFragment).commit();
        }
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Authentication.isAlreadySigned(auth)) {
            Authentication.showLoginStateItem(navigationView, getString(R.string.logout));
            Authentication.showProfileItem(navigationView);
        } else {
            Authentication.showLoginStateItem(navigationView, getString(R.string.login));
            Authentication.hideProfileItem(navigationView);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Authentication.matchResultCodes(this, requestCode, resultCode, data, RC_SIGN_IN, toolbar);
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int itemiId = item.getItemId();
        switch (itemiId) {
            case R.id.nav_courses: {
                Intent intent = new Intent(Course.this, Course.class);
                startActivity(intent);
                this.finish();
                break;
            }
            case R.id.nav_instructors: {
                Intent intent = new Intent(Course.this, Instructor.class);
                startActivity(intent);
                break;
            }
            case R.id.nav_location: {
                Uri uri = Uri.parse(getString(R.string.itsharks_location));
                UtilitiesClass.startActionViewIntent(Course.this, uri);
                break;
            }
            case R.id.nav_about: {
                Intent intent = new Intent(Course.this, About.class);
                startActivity(intent);
                break;
            }
            case R.id.nav_contacts: {
                Intent intent = new Intent(Course.this, Contacts.class);
                startActivity(intent);
                break;
            }
            case R.id.nav_reviews: {
                if (Authentication.isAlreadySigned(auth)) {
                    Intent intent = new Intent(Course.this, ReviewContainer.class);
                    startActivity(intent);
                    break;
                } else {
                    Toast.makeText(this, getString(R.string.login_first), Toast.LENGTH_LONG).show();
                    break;
                }

            }
            case R.id.nav_share: {
                shareAppLink();
                break;
            }
            case R.id.nav_account: {
                checkLoginState();
                break;
            }
            case R.id.nav_profile: {
                startActivity(new Intent(Course.this, Profile.class));
                break;
            }
            default:
                return true;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    /*
    this method is responsible for handling share menu item in the navigation drawer
     */
    private void shareAppLink() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.it_sharks_center));
        String sAux = getString(R.string.recomendation_statment);
        sAux = sAux + getString(R.string.app_url);
        i.putExtra(Intent.EXTRA_TEXT, sAux);
        startActivity(Intent.createChooser(i, getString(R.string.it_sharks)));
    }

    /*
    this method handle the action of the account menu item in the
    navigation drawer based on its title
     */
    private void checkLoginState() {
        Menu navMenu = navigationView.getMenu();
        MenuItem nav = navMenu.findItem(R.id.nav_account);
        SpannableString loginState = new SpannableString(nav.getTitle());
        if (loginState.toString().equals(getString(R.string.login))) {
            if (UtilitiesClass.isConnected(this)) {
                Authentication.startSigninUiFlow(this, RC_SIGN_IN);
            } else {
                Authentication.showSnackbar(toolbar, getString(R.string.auth_no_internet));
            }
        } else {
            Authentication.signOut(Course.this, toolbar);
        }
    }

    @Override
    public void sendCourseObject(CourseObject object, View view) {
        //case 1 pane
        if (!isTwoPane) {

             /*
                these section for using shared element transition
                while clicking at the list item int listView
                 */
            ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(
                    this,
                    view,
                    getString(R.string.shared_string)
            );
            Intent intent = new Intent(this, CourseDetailsContainer.class);
            intent.putExtra(getString(R.string.course_key), object);
            ActivityCompat.startActivity(this, intent, optionsCompat.toBundle());
        } else
        //case 2 pane
        {
            CourseDetailsContainerFragment fragment = new CourseDetailsContainerFragment();
            Bundle bundle = new Bundle();
            bundle.putParcelable(getString(R.string.course_key), object);
            fragment.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.details_container, fragment).commit();
        }
    }
}
