package aboalarbe.app.com.itsharks.Utilities;

import android.view.View;

/**
 * Created by mohamed_aboalarbe on 5/28/2017.
 */

public interface DataListener {
    void sendCourseObject(CourseObject object, View view);
}
