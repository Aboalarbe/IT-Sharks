package aboalarbe.app.com.itsharks.Utilities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;

/**
 * Created by mohamed_aboalarbe on 5/22/2017.
 */

public class UtilitiesClass {

    /*
    this method take Context and Uri to open
    a Intent View like website and facebook ....etc
     */
    public static void startActionViewIntent(Context context, Uri uri) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(uri);
        if (intent.resolveActivity(context.getPackageManager()) != null) {
            context.startActivity(intent);
        }
    }

    /*
    this method check for internet connection
     */
    public static boolean isConnected(Activity activity) {
        ConnectivityManager conn = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = conn.getActiveNetworkInfo();
        if (info != null && info.isConnectedOrConnecting())
            return true;
        else
            return false;
    }
}
