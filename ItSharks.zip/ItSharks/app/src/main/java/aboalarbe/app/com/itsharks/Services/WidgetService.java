package aboalarbe.app.com.itsharks.Services;

import android.content.Intent;
import android.widget.RemoteViewsService;

import aboalarbe.app.com.itsharks.Adapters.WidgetAdapter;

/**
 * Created by mohamed_aboalarbe on 5/30/2017.
 */

public class WidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new WidgetAdapter(this.getApplicationContext(), intent);
    }
}
