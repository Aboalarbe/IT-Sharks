package aboalarbe.app.com.itsharks.Ui;

import android.app.Activity;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.UtilitiesClass;
import butterknife.BindView;
import butterknife.ButterKnife;

public class Profile extends AppCompatActivity {

    @BindView(R.id.user_image)
    ImageView userImage;
    @BindView(R.id.username)
    TextView userName;
    @BindView(R.id.user_email)
    TextView userEmail;
    @BindView(R.id.user_id)
    TextView userId;

    FirebaseAuth auth = FirebaseAuth.getInstance();
    FirebaseUser user = auth.getCurrentUser();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        ButterKnife.bind(this);

        if (UtilitiesClass.isConnected(Profile.this)) {
            loadUserImage(Profile.this, user.getPhotoUrl(), userImage);
        } else {
            userImage.setImageResource(R.drawable.profile_photo);
        }
        userName.setText(user.getDisplayName());
        userEmail.setText(user.getEmail());
        userId.setText(user.getUid());
    }

    /*
    this method load and cache the user image using glide library
     */
    public static void loadUserImage(Activity activity, Uri uri, ImageView imageView) {
        Glide.with(activity)
                .load(uri)
                .thumbnail(0.5f)
                .crossFade()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(imageView);
    }
}
