package aboalarbe.app.com.itsharks.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import aboalarbe.app.com.itsharks.Ui.CourseContent;
import aboalarbe.app.com.itsharks.Ui.CourseInformation;

/**
 * Created by mohamed_aboalarbe on 5/17/2017.
 */

public class CourseDetailsAdapter extends FragmentStatePagerAdapter {
    private int num_tabs;
    public CourseDetailsAdapter(FragmentManager fm,int num_tabs) {
        super(fm);
        this.num_tabs=num_tabs;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position)
        {
            case 0:
            {
                return new CourseInformation();
            }
            case 1:
            {
                return new CourseContent();
            }
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return num_tabs;
    }
}
