package aboalarbe.app.com.itsharks.Data;

import android.content.ContentUris;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by mohamed_aboalarbe on 5/12/2017.
 */

public class Contract {
    public static final String AUTHORITY = "aboalarbe.app.com.itsharks";
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + AUTHORITY);

    // this class represents the courses table
    public static final class CourseTable implements BaseColumns {
        public static final String TABLE_NAME = "course";
        public static final String NAME = "name";
        public static final String IMAGE = "image";
        public static final String NO_OF_HOURS = "hours";
        public static final String NO_OF_WEEKS = "weeks";
        public static final String CONTENT = "content";

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(TABLE_NAME).build();

        public static Uri buildCourseUri(long id) {
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }
    }

    //this class represents the instructors table
    public static final class InstructorTable implements BaseColumns {
        public static final String TABLE_NAME = "instructor";
        public static final String NAME = "name";
        public static final String IMAGE = "image";
        public static final String COURSE = "course";

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(TABLE_NAME).build();

        public static Uri buildInstructorUri(long id) {
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }
    }

    //this class represents the review table that cached from the webservices
    public static final class ReviewTable implements BaseColumns {
        public static final String TABLE_NAME = "review";
        public static final String STUDENT_NAME = "student_name";
        public static final String STUDENT_REVIEW = "review_content";
        public static final String COURSENAME = "course_name";
        public static final String DATE_OF_REVIEW = "date";
        public static final String USER_IMAGE = "user_image";

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(TABLE_NAME).build();

        public static Uri buildReviewUri(long id) {
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }
    }


}
