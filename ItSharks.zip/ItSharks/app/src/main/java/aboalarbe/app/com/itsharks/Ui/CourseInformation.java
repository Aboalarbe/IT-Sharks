package aboalarbe.app.com.itsharks.Ui;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.CourseObject;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by mohamed_aboalarbe on 5/17/2017.
 */

public class CourseInformation extends Fragment {

    @BindView(R.id.course_image)
    ImageView courseImage;
    @BindView(R.id.course_name)
    TextView courseName;
    @BindView(R.id.course_weeks)
    TextView courseWeeks;
    @BindView(R.id.course_hours)
    TextView courseHours;

    String courseName_str, courseWeeks_str, courseHours_str;
    int courseImage_int;
    private CourseObject obj = CourseDetailsContainerFragment.dataObject;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getData(obj);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.course_information, container, false);
        ButterKnife.bind(this, rootView);
        courseName.setText(courseName_str);
        courseWeeks.setText(courseWeeks_str);
        courseHours.setText(courseHours_str);
        courseImage.setImageResource(courseImage_int);
        return rootView;
    }

    /*
    this method get course data from the object
     */
    private void getData(CourseObject object) {
        courseName_str = object.getCourseName();
        courseHours_str = object.getNo_hours();
        courseWeeks_str = object.getNo_weeks();
        courseImage_int = object.getCourseImage();
    }
}
