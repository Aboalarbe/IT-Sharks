package aboalarbe.app.com.itsharks.Ui;


import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import aboalarbe.app.com.itsharks.Adapters.CourseListAdapter;
import aboalarbe.app.com.itsharks.Data.Contract;
import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.CourseObject;
import aboalarbe.app.com.itsharks.Utilities.DataListener;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by mohamed_aboalarbe on 5/11/2017.
 */

public class CourseFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {

    @BindView(R.id.list_view)
    ListView listView;
    private CourseListAdapter adapter;
    private ArrayList<CourseObject> list;
    private final int LOADER_ID = 13;
    private static int scrollIndex;
    private DataListener dataListener;

    public CourseFragment() {
    }

    public void setDataListener(DataListener dataListener) {
        this.dataListener = dataListener;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        if (savedInstanceState == null ||
                !savedInstanceState.containsKey(getString(R.string.course_list_key))
                        && !savedInstanceState.containsKey(getString(R.string.course_scroll))) {
            list = new ArrayList<CourseObject>();
            scrollIndex = 0;
        } else {
            list = savedInstanceState.getParcelableArrayList(getString(R.string.course_list_key));
            scrollIndex = savedInstanceState.getInt(getString(R.string.course_scroll));
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().getSupportLoaderManager().initLoader(LOADER_ID, null, this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_course, null, false);
        ButterKnife.bind(this, rootView);
        onSelectedListItem();
        return rootView;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        scrollIndex = listView.getFirstVisiblePosition();
        outState.putParcelableArrayList(getString(R.string.course_list_key), list);
        outState.putInt(getString(R.string.course_scroll), scrollIndex);
        super.onSaveInstanceState(outState);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader<Cursor>(getContext()) {
            Cursor retCursor = null;

            @Override
            protected void onStartLoading() {
                if (retCursor != null) {
                    deliverResult(retCursor);
                } else {
                    forceLoad();
                }
            }

            @Override
            public Cursor loadInBackground() {
                try {
                    return getActivity().getContentResolver().query(
                            Contract.CourseTable.CONTENT_URI,
                            null,
                            null,
                            null,
                            null
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            public void deliverResult(Cursor data) {
                retCursor = data;
                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        if (cursor != null) {
            list.clear();
            if (cursor.moveToFirst()) {
                do {
                    String courseName = cursor.getString(cursor.getColumnIndex(Contract.CourseTable.NAME));
                    String courseWeeks = cursor.getString(cursor.getColumnIndex(Contract.CourseTable.NO_OF_WEEKS));
                    String courseHours = cursor.getString(cursor.getColumnIndex(Contract.CourseTable.NO_OF_HOURS));
                    String courseContent = cursor.getString(cursor.getColumnIndex(Contract.CourseTable.CONTENT));
                    int courseImage = cursor.getInt(cursor.getColumnIndex(Contract.CourseTable.IMAGE));
                    CourseObject object = new CourseObject(courseName, courseWeeks, courseHours, courseContent, courseImage);
                    list.add(object);
                } while (cursor.moveToNext());
            }
            adapter = new CourseListAdapter(list, getActivity());
            listView.setAdapter(adapter);
            listView.setSelection(scrollIndex);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    private void onSelectedListItem() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CourseObject objectData = list.get(position);
                dataListener.sendCourseObject(objectData, view);
            }
        });
    }
}
