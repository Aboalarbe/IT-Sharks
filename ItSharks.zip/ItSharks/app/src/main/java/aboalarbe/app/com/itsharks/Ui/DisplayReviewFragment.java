package aboalarbe.app.com.itsharks.Ui;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import aboalarbe.app.com.itsharks.Adapters.ReviewListAdapter;
import aboalarbe.app.com.itsharks.Data.Contract;
import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Sync.SyncAdapter;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by mohamed_aboalarbe on 5/23/2017.
 */

public class DisplayReviewFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>
        , SwipeRefreshLayout.OnRefreshListener {

    @BindView(R.id.list_view)
    ListView listView;
    @BindView(R.id.swap_refresh)
    SwipeRefreshLayout refreshLayout;

    private ReviewListAdapter adapter;
    private static final int LOADER_ID = 110;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.display_review, container, false);
        ButterKnife.bind(this, rootView);

        refreshLayout.setOnRefreshListener(this);
        refreshLayout.post(new Runnable() {
            @Override
            public void run() {
                refreshLayout.setRefreshing(true);
                SyncAdapter.syncImmediately(getContext());
                refreshLayout.setRefreshing(false);
            }
        });


        return rootView;
    }

    @Override
    public void onRefresh() {
        SyncAdapter.getReviewFromServer(getContext());
        refreshLayout.setRefreshing(false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().getSupportLoaderManager().initLoader(LOADER_ID, null, this);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader<Cursor>(getActivity()) {
            Cursor cursor = null;

            @Override
            protected void onStartLoading() {
                if (cursor != null) {
                    deliverResult(cursor);
                } else {
                    forceLoad();
                }
            }

            @Override
            public Cursor loadInBackground() {
                try {
                    cursor = getActivity().getContentResolver().query(
                            Contract.ReviewTable.CONTENT_URI,
                            null,
                            null,
                            null,
                            null
                    );
                    return cursor;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public void deliverResult(Cursor data) {
                cursor = data;
                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null) {
            adapter = new ReviewListAdapter(getActivity(), data);
            listView.setAdapter(adapter);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }
}
