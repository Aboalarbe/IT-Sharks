package aboalarbe.app.com.itsharks.Adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.InstructorObject;

/**
 * Created by mohamed_aboalarbe on 5/20/2017.
 */

public class InstructorListAdapter extends BaseAdapter {

    public class ViewHolder {
        TextView instructorName;
        TextView instructorCourse;
        ImageView instrucorImage;
    }

    private Activity activity;
    private ArrayList<InstructorObject> list = new ArrayList<InstructorObject>();

    public InstructorListAdapter(Activity activity, ArrayList<InstructorObject> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            LayoutInflater inflater = activity.getLayoutInflater();
            convertView = inflater.inflate(R.layout.instructor_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.instructorName = (TextView) convertView.findViewById(R.id.instructor_name);
            viewHolder.instructorCourse = (TextView) convertView.findViewById(R.id.instructor_course);
            viewHolder.instrucorImage = (ImageView) convertView.findViewById(R.id.instructor_image);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.instructorName.setText(list.get(position).getInstructorName());
        viewHolder.instructorCourse.setText(list.get(position).getInstructorCourse());
        viewHolder.instrucorImage.setImageResource(list.get(position).getInstructorImage());

        return convertView;
    }
}
