package aboalarbe.app.com.itsharks.Ui;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import aboalarbe.app.com.itsharks.R;
import butterknife.BindView;
import butterknife.ButterKnife;

public class CourseDetailsContainer extends AppCompatActivity {
    @BindView(R.id.register_fab)
    FloatingActionButton floatButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details_container);
        ButterKnife.bind(this);
        floatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CourseDetailsContainer.this, CourseRegistrationForm.class);
                startActivity(intent);
            }
        });
        if (savedInstanceState == null) {
            CourseDetailsContainerFragment courseDetailsFragment = new CourseDetailsContainerFragment();
            Bundle bundle = new Bundle();
            Intent intent = getIntent();
            if (intent != null) {
                bundle = intent.getExtras();
            }
            if (bundle != null) {
                courseDetailsFragment.setArguments(bundle);
            }
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.details_container, courseDetailsFragment).commit();
        }
    }
}
