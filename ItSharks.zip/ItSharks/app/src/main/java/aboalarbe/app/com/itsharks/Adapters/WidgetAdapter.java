package aboalarbe.app.com.itsharks.Adapters;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import aboalarbe.app.com.itsharks.Data.Contract;
import aboalarbe.app.com.itsharks.R;

/**
 * Created by mohamed_aboalarbe on 5/30/2017.
 */

public class WidgetAdapter implements RemoteViewsService.RemoteViewsFactory {

    private Context context;
    private Cursor cursor;
    int appWigetId;

    public WidgetAdapter(Context context, Intent intent) {
        this.context = context;
        this.appWigetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {
        if (cursor != null) {
            cursor.close();
        }
        cursor = context.getContentResolver().query(
                Contract.CourseTable.CONTENT_URI,
                new String[]{Contract.CourseTable.IMAGE, Contract.CourseTable.NAME},
                null,
                null,
                null
        );
    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        int count = 0;
        if (cursor != null) {
            count = cursor.getCount();
        }
        return count;
    }

    @Override
    public RemoteViews getViewAt(int position) {
        int courseImage = 0;
        String courseName = "";
        if (cursor.moveToPosition(position)) {
            courseImage = cursor.getInt(cursor.getColumnIndex(Contract.CourseTable.IMAGE));
            courseName = cursor.getString(cursor.getColumnIndex(Contract.CourseTable.NAME));
        }
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_course_item);
        views.setTextViewText(R.id.widget_course_name, courseName);
        views.setImageViewResource(R.id.widget_course_image, courseImage);
        Log.d("asdd", courseName);
        return views;
    }

    @Override
    public RemoteViews getLoadingView() {
        Log.d("asdd", "fkdjfksd");
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }
}
