package aboalarbe.app.com.itsharks.Ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import aboalarbe.app.com.itsharks.Adapters.CourseDetailsAdapter;
import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.CourseObject;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by mohamed_abolarbe on 5/17/2017.
 */

public class CourseDetailsContainerFragment extends Fragment {
    public CourseDetailsContainerFragment() {
    }

    @BindView(R.id.tab_layout)
    TabLayout tabLayout;
    @BindView(R.id.view_pager)
    ViewPager viewPager;
    public static CourseObject dataObject;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        dataObject = bundle.getParcelable(getString(R.string.course_key));
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_course_details_container, container, false);
        ButterKnife.bind(this, rootView);
        tabLayout.addTab(tabLayout.newTab()
                .setText(getString(R.string.course_info)).setIcon(R.drawable.info));
        tabLayout.addTab(tabLayout.newTab()
                .setText(getString(R.string.course_content)).setIcon(R.drawable.description));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        CourseDetailsAdapter adapter = new CourseDetailsAdapter(getFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition(), true);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        return rootView;
    }
}
