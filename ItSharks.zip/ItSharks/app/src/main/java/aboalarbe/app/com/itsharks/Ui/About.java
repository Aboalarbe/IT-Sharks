package aboalarbe.app.com.itsharks.Ui;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.UtilitiesClass;
import butterknife.BindView;
import butterknife.ButterKnife;

public class About extends AppCompatActivity {

    @BindView(R.id.image)
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        ButterKnife.bind(this);

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(getString(R.string.itsharks_website));
                UtilitiesClass.startActionViewIntent(About.this, uri);
            }
        });
    }
}
