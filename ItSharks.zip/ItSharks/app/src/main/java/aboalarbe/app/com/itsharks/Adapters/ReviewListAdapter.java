package aboalarbe.app.com.itsharks.Adapters;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import aboalarbe.app.com.itsharks.Data.Contract;
import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Ui.Profile;
import aboalarbe.app.com.itsharks.Utilities.UtilitiesClass;

/**
 * Created by mohamed_aboalarbe on 6/5/2017.
 */

public class ReviewListAdapter extends BaseAdapter {

    class ViewHolder {
        TextView studentName_review;
        TextView courseName_review;
        TextView reviewContent;
        TextView reviewDate;
        ImageView userImage;
    }

    private Activity activity;
    private Cursor cursor;

    public ReviewListAdapter(Activity activity, Cursor cursor) {
        this.activity = activity;
        this.cursor = cursor;
    }

    @Override
    public int getCount() {
        int counter = 0;
        if (cursor != null) {
            counter = cursor.getCount();
        }
        return counter;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            LayoutInflater inflater = activity.getLayoutInflater();
            convertView = inflater.inflate(R.layout.review_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.courseName_review = (TextView) convertView.findViewById(R.id.course_name);
            viewHolder.studentName_review = (TextView) convertView.findViewById(R.id.student_name);
            viewHolder.reviewContent = (TextView) convertView.findViewById(R.id.feedback);
            viewHolder.reviewDate = (TextView) convertView.findViewById(R.id.date);
            viewHolder.userImage = (ImageView) convertView.findViewById(R.id.user_photo);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        String courseName = "";
        String studentName = "";
        String feedback = "";
        String date = "";
        String imageUrl = "";

        if (cursor.moveToPosition(position)) {
            courseName = cursor.getString(cursor.getColumnIndex(Contract.ReviewTable.COURSENAME));
            studentName = cursor.getString(cursor.getColumnIndex(Contract.ReviewTable.STUDENT_NAME));
            feedback = cursor.getString(cursor.getColumnIndex(Contract.ReviewTable.STUDENT_REVIEW));
            imageUrl = cursor.getString(cursor.getColumnIndex(Contract.ReviewTable.USER_IMAGE));
            date = cursor.getString(cursor.getColumnIndex(Contract.ReviewTable.DATE_OF_REVIEW));
        }

        viewHolder.studentName_review.setText(studentName);
        viewHolder.courseName_review.setText(courseName);
        viewHolder.reviewContent.setText(feedback);
        viewHolder.reviewDate.setText(date);

        if (UtilitiesClass.isConnected(activity)) {
            Profile.loadUserImage(activity, Uri.parse(imageUrl), viewHolder.userImage);
        } else {
            viewHolder.userImage.setImageResource(R.drawable.profile_photo);
        }

        return convertView;
    }
}
