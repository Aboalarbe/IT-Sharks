package aboalarbe.app.com.itsharks.Ui;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Services.WidgetService;

/**
 * Implementation of App Widget functionality.
 */
public class CourseListWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int i = 0; i < appWidgetIds.length; i++) {
            Intent intent = new Intent(context, WidgetService.class);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetIds[i]);
            intent.setData(Uri.parse(intent.toUri(Intent.URI_INTENT_SCHEME)));
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.course_list_widget);
            Intent clickedIntent = new Intent(context, Course.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, clickedIntent, 0);
            views.setOnClickPendingIntent(R.id.widget_bar, pendingIntent);
            views.setRemoteAdapter(appWidgetIds[i], R.id.widget_listview, intent);
            views.setEmptyView(R.id.widget_listview, R.id.widget_empty_view);
            appWidgetManager.updateAppWidget(appWidgetIds[i], views);
        }
        super.onUpdate(context, appWidgetManager, appWidgetIds);
    }
}
