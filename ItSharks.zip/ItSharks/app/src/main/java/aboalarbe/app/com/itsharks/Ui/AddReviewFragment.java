package aboalarbe.app.com.itsharks.Ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.UtilitiesClass;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by mohamed_aboalarbe on 5/23/2017.
 */

public class AddReviewFragment extends Fragment {

    @BindView(R.id.student_name)
    EditText studentName;
    @BindView(R.id.course_name)
    EditText courseName;
    @BindView(R.id.feedback)
    EditText feedback;
    @BindView(R.id.send)
    Button submit;
    @BindView(R.id.progress_bar)
    ProgressBar bar;
    String studentName_str, courseName_str, feedback_str;
    String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    FirebaseAuth auth=FirebaseAuth.getInstance();
    FirebaseUser user=auth.getCurrentUser();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.add_review, container, false);
        ButterKnife.bind(this, rootView);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag = getInputData();
                if (flag) {
                    if (UtilitiesClass.isConnected(getActivity())) {
                        bar.setVisibility(View.VISIBLE);
                        sendReviewDataToServer();
                    } else {
                        Toast.makeText(getActivity(), getString(R.string.check_connection), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(getActivity(), getString(R.string.input_error), Toast.LENGTH_SHORT).show();
                }
            }
        });
        return rootView;
    }

    /*
            this method that get the data from the user and check if empty
             */
    private boolean getInputData() {
        studentName_str = studentName.getText().toString();
        courseName_str = courseName.getText().toString();
        feedback_str = feedback.getText().toString();
        if (studentName_str.isEmpty() || courseName_str.isEmpty() || feedback_str.isEmpty())

            return false;

        else
            return true;
    }

    /*
        this method send the data that user entered to the backend server
         */
    private void sendReviewDataToServer() {
        String serverUrl = getString(R.string.server_url_review);
        RequestQueue queue = Volley.newRequestQueue(getActivity());
        StringRequest request = new StringRequest(Request.Method.POST, serverUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    String result = object.getString(getString(R.string.response));
                    if (result.equalsIgnoreCase(getString(R.string.done))) {
                        bar.setVisibility(View.GONE);
                        Toast.makeText(getActivity(), getString(R.string.review_success), Toast.LENGTH_LONG).show();
                        getActivity().finish();
                    } else {
                        bar.setVisibility(View.GONE);
                        Toast.makeText(getActivity(), getString(R.string.review_error), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                bar.setVisibility(View.GONE);
                Toast.makeText(getActivity(), getString(R.string.unexcepected_error), Toast.LENGTH_SHORT).show();
            }
        }) {
            /*
            send data parameters to the php file which connect to mysql database
             */
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put(getString(R.string.student_name_key), studentName_str);
                map.put(getString(R.string.course_name_key), courseName_str);
                map.put(getString(R.string.feedback_key), feedback_str);
                map.put(getString(R.string.date_key), date);
                map.put(getString(R.string.user_image_key),user.getPhotoUrl().toString());
                return map;
            }
        };
        queue.add(request);
    }
}
