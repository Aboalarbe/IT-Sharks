package aboalarbe.app.com.itsharks.Ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import aboalarbe.app.com.itsharks.R;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by mohamed_aboalarbe on 5/17/2017.
 */

public class CourseContent extends Fragment {

    @BindView(R.id.course_content)
    TextView courseContent;

    private String courseContent_str = CourseDetailsContainerFragment.dataObject.getCourseContent();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.course_content, container, false);
        ButterKnife.bind(this, rootView);
        courseContent.setText(courseContent_str);
        return rootView;
    }
}
