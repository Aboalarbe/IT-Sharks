package aboalarbe.app.com.itsharks.Utilities;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by mohamed_aboalarbe on 6/5/2017.
 */

public class ReviewObject implements Parcelable {

    private String studentName;
    private String review_course;
    private String reviewContent;
    private String reviewDate;
    private String userImage;

    public ReviewObject(String studentName, String courseName, String reviewContent, String reviewDate, String userImage) {
        this.studentName = studentName;
        this.review_course = courseName;
        this.reviewContent = reviewContent;
        this.reviewDate = reviewDate;
        this.userImage = userImage;
    }

    protected ReviewObject(Parcel in) {
        studentName = in.readString();
        review_course = in.readString();
        reviewContent = in.readString();
        reviewDate = in.readString();
        userImage = in.readString();
    }

    public static final Creator<ReviewObject> CREATOR = new Creator<ReviewObject>() {
        @Override
        public ReviewObject createFromParcel(Parcel in) {
            return new ReviewObject(in);
        }

        @Override
        public ReviewObject[] newArray(int size) {
            return new ReviewObject[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(studentName);
        dest.writeString(review_course);
        dest.writeString(reviewContent);
        dest.writeString(reviewDate);
        dest.writeString(userImage);
    }

    public String getStudentName() {
        return studentName;
    }

    public String getReview_course() {
        return review_course;
    }

    public String getReviewContent() {
        return reviewContent;
    }

    public String getReviewDate() {
        return reviewDate;
    }

    public String getUserImage() {
        return userImage;
    }
}
