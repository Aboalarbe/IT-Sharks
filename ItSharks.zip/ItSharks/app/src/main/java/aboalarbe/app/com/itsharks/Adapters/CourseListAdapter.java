package aboalarbe.app.com.itsharks.Adapters;


import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.CourseObject;

/**
 * Created by mohamed_aboalarbe on 5/14/2017.
 */

public class
CourseListAdapter extends BaseAdapter {

    static class ViewHolder {
        TextView courseName;
        ImageView courseImage;
    }

    private ArrayList<CourseObject> list = new ArrayList<CourseObject>();
    private Activity activity;

    public CourseListAdapter(ArrayList<CourseObject> list, Activity activity) {
        this.list = list;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            LayoutInflater inflater = activity.getLayoutInflater();
            convertView = inflater.inflate(R.layout.course_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.courseImage = (ImageView) convertView.findViewById(R.id.course_image);
            viewHolder.courseName = (TextView) convertView.findViewById(R.id.course_name);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.courseName.setText(list.get(position).getCourseName());
        viewHolder.courseImage.setImageResource(list.get(position).getCourseImage());

        return convertView;
    }
}
