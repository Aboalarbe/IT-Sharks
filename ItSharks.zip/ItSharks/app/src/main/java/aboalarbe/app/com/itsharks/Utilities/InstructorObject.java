package aboalarbe.app.com.itsharks.Utilities;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by mohamed_aboalarbe on 5/20/2017.
 */

public class InstructorObject implements Parcelable {

    private String instructorName;
    private String instructorCourse;
    private int instructorImage;

    public InstructorObject(String instructorName, String instructorCourse, int instructorImage) {
        this.instructorName = instructorName;
        this.instructorCourse = instructorCourse;
        this.instructorImage = instructorImage;
    }

    protected InstructorObject(Parcel in) {
        instructorCourse = in.readString();
        instructorCourse = in.readString();
        instructorImage = in.readInt();
    }

    public static final Creator<InstructorObject> CREATOR = new Creator<InstructorObject>() {
        @Override
        public InstructorObject createFromParcel(Parcel in) {
            return new InstructorObject(in);
        }

        @Override
        public InstructorObject[] newArray(int size) {
            return new InstructorObject[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(instructorName);
        dest.writeString(instructorCourse);
        dest.writeInt(instructorImage);
    }

    public String getInstructorName() {
        return instructorName;
    }

    public String getInstructorCourse() {
        return instructorCourse;
    }

    public int getInstructorImage() {
        return instructorImage;
    }
}
