package aboalarbe.app.com.itsharks.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import aboalarbe.app.com.itsharks.R;

/**
 * Created by mohamed_aboalarbe on 5/12/2017.
 */

public class DbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "itsharks.db";
    private static final int DATABASE_VERSION = 1;

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //this String Command To create course table
        final String CREATE_TABLE_COURSE =
                "CREATE TABLE " + Contract.CourseTable.TABLE_NAME + " (" + Contract.CourseTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        Contract.CourseTable.NAME + " TEXT NOT NULL, " +
                        Contract.CourseTable.IMAGE + " INTEGER NOT NULL, " +
                        Contract.CourseTable.CONTENT + " TEXT NOT NULL, " +
                        Contract.CourseTable.NO_OF_WEEKS + " TEXT NOT NULL, " +
                        Contract.CourseTable.NO_OF_HOURS + " TEXT NOT NULL " + ");";

        //this String Comman To Create instructor Table
        final String CREATE_TABLE_INSTRUCTOR =
                "CREATE TABLE " + Contract.InstructorTable.TABLE_NAME + " (" + Contract.InstructorTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        Contract.InstructorTable.NAME + " TEXT NOT NULL, " +
                        Contract.InstructorTable.IMAGE + " INTEGER NOT NULL, " +
                        Contract.InstructorTable.COURSE + " TEXT NOT NULL " + ");";

        //this String Comman To Create instructor Table
        final String CREATE_TABLE_REVIEW =
                "CREATE TABLE " + Contract.ReviewTable.TABLE_NAME + " (" + Contract.ReviewTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        Contract.ReviewTable.STUDENT_NAME + " TEXT NOT NULL, " +
                        Contract.ReviewTable.STUDENT_REVIEW + " TEXT NOT NULL, " +
                        Contract.ReviewTable.DATE_OF_REVIEW + " TEXT NOT NULL, " +
                        Contract.ReviewTable.USER_IMAGE + " TEXT NOT NULL, " +
                        Contract.ReviewTable.COURSENAME + " TEXT NOT NULL " + ");";

        //actually created of these Tables int the database
        db.execSQL(CREATE_TABLE_COURSE);
        db.execSQL(CREATE_TABLE_INSTRUCTOR);
        db.execSQL(CREATE_TABLE_REVIEW);

        // these all data for the course table
        int[] courseImages = new int[]{
                R.drawable.java,
                R.drawable.android,
                R.drawable.asp,
                R.drawable.php,
                R.drawable.cplus,
                R.drawable.ccna,
                R.drawable.ccnp,
                R.drawable.oracle,
                R.drawable.adf,
                R.drawable.wweb_ddesignn,
                R.drawable.object,
                R.drawable.datastru,
                R.drawable.python,
                R.drawable.administrator
        };
        String[] courseNames = new String[]{
                "Java",
                "Android",
                "C#/ASP.Net",
                "PhP",
                "C/C++",
                "CCNA",
                "CCNP",
                "Oracle",
                "Oracle ADF",
                "Web Design",
                "Object Orinted",
                "Data Structure",
                "Python",
                "Oracle Adm"
        };
        String[] courseHours = new String[]{
                "104 Hours",
                "92 Hours",
                "100 Hours",
                "98 Hours",
                "40 Hours",
                "80 Hours",
                "80 Hours",
                "120 Hours",
                "114 Hours",
                "48 Hours",
                "35 Hours",
                "35 Hours",
                "46 Hours",
                "120 Hours"
        };
        String[] courseWeeks = new String[]{
                "9 Weeks",
                "8 Weeks",
                "9 Weeks",
                "9 Weeks",
                "4 Weeks",
                "7 Weeks",
                "7 Weeks",
                "10 Weeks",
                "10 Weeks",
                "4 Weeks",
                "3 Weeks",
                "3 Weeks",
                "4 Weeks",
                "10 Weeks"
        };
        String[] courseContent = new String[]{

                //content for java course.
                "Introduction and Overview \n" +
                        "\n" +
                        "introduction to stand-alone application\n" +
                        "overview about JDK,JVM,JRE\n" +
                        "How to compile code into bytecode\n" +
                        "overview about IDE\n" +
                        "overview about libraries\n" +
                        "Declaring and initializing variables\n" +
                        "Datatypes\n" +
                        "How to print in Console\n" +
                        "How to scan values from user\n" +
                        " Control Structure \n" +
                        "\n" +
                        "If, if-else statements\n" +
                        "While loop\n" +
                        "Do while loop\n" +
                        "For & foreach loop\n" +
                        "Switch statement\n" +
                        " Arrays \n" +
                        "\n" +
                        "Arrays\n" +
                        "String\n" +
                        "OOP \n" +
                        "\n" +
                        "Overview about traditional programming,\n" +
                        "Access Modifiers,\n" +
                        "Introduction to classes and methods,\n" +
                        "Introduction to object oriented programming\n" +
                        "Encapsulation\n" +
                        "Inheritance\n" +
                        "Polymorphism\n" +
                        "Abstraction\n" +
                        "Interfaces\n" +
                        "Intro to Threads\n" +
                        "Storing and Retrieving Data with File I/O\n" +
                        "\n" +
                        "Handling exceptions with try and catch.\n" +
                        "Reading and writing files.\n" +
                        "Creating, deleting and renaming files.\n" +
                        "Obtaining directory and file information.\n" +
                        "GUI \n" +
                        "\n" +
                        "Introduction to Dialogs and message boxes.\n" +
                        "Introduction to Graphics User Interface,\n" +
                        "How to use components(Swing UI)\n" +
                        " SQL \n" +
                        "\n" +
                        "Introduction to SQL,\n" +
                        "SQL statements,\n" +
                        "Retrieving and processing results.\n" +
                        "JDBC \n" +
                        "\n" +
                        "Introduction to JDBC,\n" +
                        "Choosing database drivers,\n" +
                        " Connecting to a database.\n" +
                        "Implementing application using JDBC\n" +
                        "Project \n" +
                        "\n" +
                        "Project In windows Form \n" +
                        "Group of 2-3 persons select an idea.\n" +
                        "The lecturer discusses the code with you.\n\n" +
                        "Java EE Course\n" +
                        "Introduction\n" +
                        "\n" +
                        "Introduction to web programming.\n" +
                        "Introduction to HTML\n" +
                        " Servlets and Application Server\n" +
                        "\n" +
                        "Introduction to Application Server\n" +
                        "Servlet life cycle methods\n" +
                        "Creating Forms\n" +
                        "\n" +
                        " Creating Java Server Pages (JSP) \n" +
                        "\n" +
                        "Using JSP scripts\n" +
                        "JSP variables scope and objects\n" +
                        "Forms interaction using JSP\n" +
                        " Application Variables scope\n" +
                        "\n" +
                        "Managing cookies\n" +
                        "Storing common application data\n" +
                        "Creating a unique session for each user\n" +
                        "Storing and retrieving Java objects within sessions\n" +
                        "Controlling a session's life span\n" +
                        "Creating application and session event listeners\n" +
                        "Page redirection\n" +
                        "\n" +
                        "Forwarding vs send redirection\n" +
                        "JSP import tags\n" +
                        "Accessing Databases with Servlets\n" +
                        "\n" +
                        "Connecting to the database.\n" +
                        "Submitting SQL statements\n" +
                        "CRUD functions\n" +
                        "Retrieving and processing data\n" +
                        "Constructing an HTML table\n" +
                        "Developing JavaServer Faces (JSF) Applications \n" +
                        "\n" +
                        "JSF Framework overview\n" +
                        "Identifying the JSF core components\n" +
                        "Managing application flow using JSF navigation model\n" +
                        "Project\n" +
                        "\n" +
                        "Group of 2-3 persons select an idea.\n" +
                        "The lecturer discusses the code with you.",

                //content for android course
                /////////////////////////////////////////////////////

                "JAVA\n" +
                        "\n" +
                        "Java What's Java ?\n" +
                        "Java history.\n" +
                        "Java Bytecode.\n" +
                        "Java virtual machine.\n" +
                        "JRE(Java runtime environment ).\n" +
                        "JDK (Java Development kit ).\n" +
                        "SDK(Software Development Kit ).\n" +
                        "API(Application Programming Interfaces ).\n" +
                        "Variables Data Types.\n" +
                        "Strings.\n" +
                        "Input-output.\n" +
                        "Comments.\n" +
                        "Math Operations.\n" +
                        "Conditional statement (if- switch).\n" +
                        "Looping.\n" +
                        "Exceptions.\n" +
                        "Streams (input stream- output stream).\n" +
                        "Casting.\n" +
                        "OOP\n" +
                        "\n" +
                        "Class.\n" +
                        "Object Member.\n" +
                        "Variable Member.\n" +
                        "method.\n" +
                        "Constructor.\n" +
                        "Access Control Modifiers.\n" +
                        "Inheritance.\n" +
                        "Polymorphism.\n" +
                        "Interfaces.\n" +
                        "Abstraction.\n\n" +
                        "Introduction to Android\n" +
                        "\n" +
                        "What’s Android.\n" +
                        "Why Android.\n" +
                        "Android Market.\n" +
                        "Android Versions.\n" +
                        " Android Architecture\n" +
                        "\n" +
                        "Android Stack.\n" +
                        "Android Features.\n" +
                        "Android Architecture layer.\n" +
                        " Tools\n" +
                        "\n" +
                        "SDK (software development kit ).\n" +
                        "JDK (java development kit ).\n" +
                        "IDE (integrated development environment.\n" +
                        " Android Studio\n" +
                        "\n" +
                        "Setup Android Studio.\n" +
                        "Android Manifest.\n" +
                        "Important Folders.\n" +
                        "Important Buttons.\n" +
                        "LogCat.\n" +
                        "Emulator  and genymotion.\n" +
                        "Android Components\n" +
                        "\n" +
                        "Activities.\n" +
                        "Services.\n" +
                        "Broadcast Receivers.\n" +
                        "Content Providers.\n" +
                        " Building Application UI\n" +
                        "\n" +
                        "Material design concept.\n" +
                        "Layouts.\n" +
                        "Layout types.\n" +
                        "View class.\n" +
                        "Attributes.\n" +
                        " Activities\n" +
                        "\n" +
                        "Life Cycle.\n" +
                        "Call Back.\n" +
                        "Methods Interacting with UI.\n" +
                        "Resources.\n" +
                        " Intents\n" +
                        "\n" +
                        "Explicit Intents.\n" +
                        "Implicit Intent.\n" +
                        "Intent Filter.\n" +
                        "listView\n" +
                        "\n" +
                        "Adapter.\n" +
                        "Listview.\n" +
                        "CustomListView.\n" +
                        "Networking\n" +
                        "\n" +
                        "Threads.\n" +
                        "AsyncTask.\n" +
                        "Volley library.\n" +
                        "JSON Parsing.\n" +
                        "Data Storing\n" +
                        "\n" +
                        "Shared preferences.\n" +
                        "Internal storage.\n" +
                        "External storage.\n" +
                        "SQLite.\n" +
                        "Services\n" +
                        "\n" +
                        "Overview of services in Android.\n" +
                        "Implementing a Service.\n" +
                        "a Service lifecycle.\n" +
                        "Fragments\n" +
                        "\n" +
                        "Static.\n" +
                        "Dynamic.\n" +
                        "Android Fragments Tabs.\n" +
                        "Camera\n" +
                        "\n" +
                        "Working with camera.\n" +
                        "Multimedia in Android\n" +
                        "\n" +
                        "Simple Media Player APP.\n" +
                        "Simple video playback.\n" +
                        "Menus\n" +
                        "\n" +
                        "Context Menu.\n" +
                        "Popup Menu.\n" +
                        "Option Menus.\n" +
                        "Notifications\n" +
                        "\n" +
                        "Notification properties.\n" +
                        "Attach Actions to notification.\n" +
                        "Pending Intent.\n" +
                        "Maps and Locations\n" +
                        "\n" +
                        "Working with Google Maps.\n" +
                        "Finding current location and listening for changes in location.\n" +
                        "Working with GPS.",

                //content for Asp.net course
                ////////////////////////////////////////////////////////

                "C-Sharp Course\n\n" +
                        " Introduction and Principles \n" +
                        "\n" +
                        "Introduction\n" +
                        "Reading and writing to a console\n" +
                        "Built-in data types\n" +
                        "String data type\n" +
                        "Control Structure \n" +
                        "\n" +
                        "Operators\n" +
                        "Nullable Types\n" +
                        "Datatype conversions\n" +
                        "Comments\n" +
                        "If statement\n" +
                        "Switch statement\n" +
                        "While loop\n" +
                        "Do while loop\n" +
                        "For & foreach loop\n" +
                        " Functions, Arrays\n" +
                        "\n" +
                        "arrays(one & two dimension).\n" +
                        "Methods.\n" +
                        "Method parameters.\n" +
                        "passing array to function.\n" +
                        " Classes \n" +
                        "\n" +
                        "Class - Introduction\n" +
                        "Static & Instance members\n" +
                        "Method hiding \n" +
                        "Structs\n" +
                        "Classes Vs Structs\n" +
                        " OOP\n" +
                        "\n" +
                        "Encapsulations\n" +
                        "Polymorphism\n" +
                        "Method overriding Vs hiding\n" +
                        "Method overloading. \n" +
                        "Inheritance.\n" +
                        "Diamond Problem\n" +
                        "Multiple inheritance \n" +
                        "Classes Properties \n" +
                        "\n" +
                        "Interfaces\n" +
                        "Explicit interface implementation\n" +
                        "Abstract Classes\n" +
                        "Abstract Classes Vs Interfaces\n" +
                        " Delegates, Exception Handling \n" +
                        "\n" +
                        "Delegates\n" +
                        "Multicast Delegates\n" +
                        "Exception Handling\n" +
                        "Inner Exceptions\n" +
                        "Custom Exceptions\n" +
                        "Exception Handling Abuse\n" +
                        "Preventing Exception Handling Abuse\n" +
                        "Enums, Modifiers, Reflection\n" +
                        "\n" +
                        "Enums\n" +
                        "Enums Concepts\n" +
                        "Types vs Type Members\n" +
                        "Access Modifiers - Private, Public and Protected\n" +
                        "Access Modifiers - Internal and Protected Internal\n" +
                        "Access Modifiers for types ,Attributes\n" +
                        "Reflection\n" +
                        "Late binding using reflection\n" +
                        " Generics\n" +
                        "\n" +
                        "Generic Collections\n" +
                        "Difference between Convert.ToString() and ToString() method\n" +
                        "Difference between string and stringbuilder\n" +
                        "Dictionary, list, Lambada\n" +
                        "\n" +
                        "dictionary\n" +
                        "List collection class \n" +
                        "When to use a dictionary over list\n" +
                        "Anonymous methods\n" +
                        "Lambda expression\n" +
                        " ADO\n" +
                        "\n" +
                        "What is ADO.NET\n" +
                        "SQLConnection object in ADO.NET\n" +
                        "Storing and retrieving connection\n" +
                        "SqlCommand in ado.net\n" +
                        "Calling a stored procedure with output parameters\n" +
                        "SqlDataReader object in ADO.NET\n" +
                        "SqlDataReader object's NextResult() method\n" +
                        "SqlDataAdapter in ADO.NET\n" +
                        " Project \n" +
                        "\n" +
                        "Project In windows Form \n" +
                        "Group of 2-3 persons select an idea.\n" +
                        "The lecturer discusses the code with you.\n\n" +
                        "Asp-Net-Course\n\n" +
                        "Introduction \n" +
                        "\n" +
                        "Introduction to web programming and ASP.NET.\n" +
                        "Create web application using Visual Studio and C#.\n" +
                        "Create and add code-behind file to an ASP.NET web form.\n" +
                        "Examine common ASP.NET Controls\n" +
                        "Controls\n" +
                        "\n" +
                        "Connecting to a Database in an ASP.NET application\n" +
                        "ASP.NET Data Controls.\n" +
                        "Session management.\n" +
                        "Validation controls.\n" +
                        " Master Pages\n" +
                        "\n" +
                        "Master pages.\n" +
                        "Configuring and deploying an ASP.NET web application\n" +
                        " MVC \n" +
                        "\n" +
                        "Introduction to MVC 4.\n" +
                        "Adding a Controller.\n" +
                        "Adding a View.\n" +
                        "Adding a Model.\n" +
                        "Accessing your Model's data from a Controller.\n" +
                        "Examining the Edit Methods and Edit View.\n" +
                        "Adding new Fields.\n" +
                        "Adding Validations,\n" +
                        "Delete Methods\n" +
                        " Database Concepts\n" +
                        "\n" +
                        "SQL Basics.\n" +
                        "DDL,DML,DCL.\n" +
                        "Join.\n" +
                        "Procedures.\n" +
                        "Functions.\n" +
                        "Views.\n" +
                        "Triggers.\n" +
                        "ADO.Net\n" +
                        "\n" +
                        "ADO.NET Architecture.\n" +
                        "Connection Object.\n" +
                        "Command Object.\n" +
                        "DataReader Object.\n" +
                        "DataAdapter Object.\n" +
                        "DataSet Object.\n" +
                        "DataView Object.\n" +
                        "Use ADO.NET to access data in an application.\n" +
                        " LINQ\n" +
                        "\n" +
                        "Building to LINQ to Objects.\n" +
                        "Entity Frame Work.\n" +
                        "Lambada Expression ;\n" +
                        "LINQ to XML.\n" +
                        "LINQ to SQL.\n" +
                        "Project\n" +
                        "\n" +
                        "Group of 2-3 persons select an idea.\n" +
                        "The lecturer discusses the code with you.",

                //content for php course
                //////////////////////////////////////////////////////////////////

                "Web Design Course\n\n" +
                        "Intro to web fundamentals\n" +
                        "Intro for Hyper Text Markup Language\n" +
                        "Understanding the web page structure\n" +
                        "How pages are executed and compiled?\n" +
                        "What the component of web pages\n" +
                        "HTML4\n" +
                        "Study the Tags of HTML4\n" +
                        "How to make good design page using HTML4\n" +
                        "HTML5\n" +
                        "Study removed tags in HTML4\n" +
                        "Study new tags in HTML5\n" +
                        "Building full structured web page using HTML4 and HTML5\n" +
                        "CSS2\n" +
                        "Study the difference between CSS [Cascading Style Sheets] and HTML\n" +
                        "The structure of CSS code\n" +
                        "How to link between HTML and CSS\n" +
                        "Study the selectors and what are their priorities\n" +
                        "Study the formatting and values of each priorities\n" +
                        "CSS3\n" +
                        "Study removed properties in CSS2\n" +
                        "Study new properties in CSS3\n" +
                        "Building full well designed web pages using HTML4, HTML5, CSS2 and CSS3\n" +
                        "PSD to HTML\n" +
                        "Understand the basics of Photoshop\n" +
                        "How you can get a free PSD template\n" +
                        "Study the principles, you should follow to convert PSD image to HTML code\n" +
                        "Workshop with converting a PSD to website\n" +
                        "JavaScript\n" +
                        "Study the principles of programming\n" +
                        "Variables\n" +
                        "Loops\n" +
                        "Conditional statements\n" +
                        "Understand DOM\n" +
                        "How to design and animate page using JavaScript\n" +
                        "How to build a plugin from scratch\n" +
                        "JQuery\n" +
                        "What and why is JQuery?\n" +
                        "The slogan of JQuery\n" +
                        "How to use JQuery\n" +
                        "What is the CDN?\n" +
                        "Study the main functions of JQuery library to animate your page\n" +
                        "How to build a plugin\n" +
                        "How to use ready plugins, how to get it and how to edit or customize it?\n" +
                        "Bootstrap\n" +
                        "Understand the concepts of responsive design\n" +
                        "Why should use bootstrap?\n" +
                        "How to build first web page using bootstrap?\n" +
                        "Understanding the grid system\n" +
                        "Study the classes of bootstrap and how to use its documentation?\n" +
                        "Project\n" +
                        "Building a web site that fits all screen devices\n" +
                        "Using all learnt technologies\n" +
                        "Workshop\n" +
                        "full day in IT Sharks, Implemting real projects as like as in a company\n\n" +
                        "Php-Mysql Course\n\n" +
                        "Introduction\n" +
                        "Introduction to World Wide Web.\n" +
                        "Understanding the difference between web design and web development\n" +
                        "Understanding the rules of dynamic website\n" +
                        "History Understanding client/server roles Apache, PHP, MySQL, Wamp Installation, PHP Basic syntax.\n" +
                        "PHP Fundamentals\n" +
                        "PHP data Types.\n" +
                        "PHP Variables.\n" +
                        "echo / print.\n" +
                        "PHP Operators.\n" +
                        "Control statements\n" +
                        "Conditional statements.\n" +
                        "If-else\n" +
                        "switch\n" +
                        " Loops.\n" +
                        "While\n" +
                        "For\n" +
                        "PHP Arrays\n" +
                        "PHP Enumerated Arrays.\n" +
                        "PHP Associative Arrays.\n" +
                        "Array Iteration.\n" +
                        "PHP Multi-Dimensional Arrays.\n" +
                        "Array Functions.\n" +
                        "Foreach loop\n" +
                        "Array functions\n" +
                        "PHP Functions \n" +
                        "Understand the difference between user-defined and built-in functions\n" +
                        "PHP Functions. Syntax, Arguments, Variables, References.\n" +
                        "Return Values, Variable Scope.\n" +
                        "How to divide your code\n" +
                        "PHP include().\n" +
                        "PHP require().\n" +
                        "PHP Forms\n" +
                        "PHP Form handling.\n" +
                        "PHP GET, PHP POST, PHP Form Validation.\n" +
                        "PHP Form Sanitization.\n" +
                        "File uploading.\n" +
                        "XSS filtering\n" +
                        "How to filter your data\n" +
                        "PHP Strings Handling \n" +
                        "Strings and Patterns.\n" +
                        "Matching, Extracting.\n" +
                        "Searching Replacing.\n" +
                        "Formatting, PCRE.\n" +
                        "MySQL\n" +
                        "Intro to the history of database\n" +
                        "Difference between DBMS, DB and SQL\n" +
                        "DDL \"Data Definition Language\"\n" +
                        "How to design Database\n" +
                        "Understanding ERD \"Entity Relationship Diagram\"\n" +
                        "Understanding the relations between tables\n" +
                        "How to create, alter and drop the tables\n" +
                        "DML \"Data Manipulation Language\"\n" +
                        "Study insert statement\n" +
                        "Study update statement\n" +
                        "Study delete statement\n" +
                        "Study select statement\n" +
                        "Select types\n" +
                        "How to search in database\n" +
                        "Condition operators\n" +
                        "Sorting data\n" +
                        "Aggregation functions\n" +
                        "Joins\n" +
                        "How to connect PHP with MYSQL\n" +
                        "Understand the lifecycle of connection\n" +
                        "Difference between MYSQL, MYSQLI and PDO\n" +
                        "Implement CRUD functions for tables\n" +
                        "OOP [Object Oriented Concepts]\n" +
                        "Understanding the theory of OOP\n" +
                        "Understanding Encapsulation\n" +
                        "Inheritance\n" +
                        "Polymorphism\n" +
                        "Abstraction\n" +
                        "PHP Cookies & PHP Sessions\n" +
                        "PHP Cookie handling.\n" +
                        "PHP Session Handling.\n" +
                        "PHP Login Session.\n" +
                        "Managing user ACL,PHP Cookie handling.\n" +
                        "PHP Session Handling.\n" +
                        "PHP Login Session.\n" +
                        "Managing user ACL.\n" +
                        "PHP AJAX and JSON\n" +
                        "Submit form using AJAX and JSON\n" +
                        "How to distribute you code natively to pure MVC\n" +
                        "Frameworks and CMS\n" +
                        "Intro to wordpress CMS\n" +
                        "Intro to Codeigniter or Yii2 or Laravel framework\n" +
                        "Project\n" +
                        "Implementing full CMS web site\n" +
                        "Hosting\n" +
                        "how to book a domain?\n" +
                        "how to purchase a hosting?\n" +
                        "how to publish your web site",

                //this contnet for c++ course
                /////////////////////////////////////////////////////////

                "Introduction and Principles \n" +
                        "What is programming language?\n" +
                        "How the programs run?\n" +
                        "Output functions.\n" +
                        "Variables and Data types.\n" +
                        "Read value from user and process it.\n" +
                        "Mathematical basics.\n" +
                        "Control Structure \n" +
                        "Sequence Control structure.\n" +
                        "Selection Control Structures.\n" +
                        "If-else.\n" +
                        "Dangling-else Problem\n" +
                        "Repetition (Loops) \n" +
                        "For, while, do-while.\n" +
                        "Counter-Controlled Repetition.\n" +
                        "Sentinel-Controlled Repetition.\n" +
                        "Break and continue Statements.\n" +
                        "Nested Control Statements.\n" +
                        "Workshop 1:\n" +
                        "Implementing ATM System\n" +
                        "Functions \n" +
                        "Function Prototypes, built in functions and user defined functions.\n" +
                        "References and Reference Parameters, Scope Rules.\n" +
                        "Function overloading, and Function Templates.\n" +
                        "Inline Functions and recursive functions.\n" +
                        "Math Library Functions.\n" +
                        "Arrays\n" +
                        "Introduction to arrays.\n" +
                        "Passing arrays to functions.\n" +
                        "Searching Arrays with Linear Search.\n" +
                        "2-D arrays.\n" +
                        "Multidimensional arrays. \n" +
                        "Workshop 2:\n" +
                        "Implementing XO game\n" +
                        "Pointers\n" +
                        "Call by reference, Call by value, and const member functions.\n" +
                        "Pointer Variable Declarations and Initialization.\n" +
                        "Pointer Operators.\n" +
                        "Passing Arguments to Functions by Reference with Pointers.\n" +
                        "Relationship between Pointers and Arrays.\n" +
                        "Pointer-Based String Processing.\n" +
                        "Advanced Topics (Search, Sort ...)\n" +
                        "Bubble sort function.\n" +
                        "Bubble sort using array.\n" +
                        "Pointer to functions.\n" +
                        "Linear search.\n" +
                        "Binary search.\n" +
                        "Search by recursion.\n" +
                        "Structures, Union and Enumeration\n" +
                        "Define struct.\n" +
                        "Use structs with functions.\n" +
                        "Union\n" +
                        "Enumeration\n" +
                        "Workshop 3:\n" +
                        "Implementing Pharmacy system\n" +
                        "Files Streaming\n" +
                        "Files and Streams.\n" +
                        "Creating a Sequential File, Create, read and update file.\n" +
                        "Random-Access Files.\n" +
                        "Writing Data Randomly to a Random-Access File.\n" +
                        "Memory Allocation and Bitwise Operators\n" +
                        "Dynamic Memory allocation.\n" +
                        "Bitwise Operators.\n" +
                        "Function with dynamic numbers of arguments\n" +
                        "Workshop 4: Project \n" +
                        "Group of 2-3 persons select an idea.\n" +
                        "The lecturer discusses the code with you.",

                //this content for ccna course
                ////////////////////////////////////////////////////////////////////

                "Intoduction \n" +
                        "OSI &TCP/IP layer.\n" +
                        "Transport Layer: TCP and UDP.\n" +
                        "Network Layer: IPv4 Addressing and Routing.\n" +
                        "Fundamentals of Ethernet LANs.\n" +
                        "Cisco Device & Cable.\n" +
                        "Wireless.\n" +
                        "Basic Configuration.\n" +
                        "Routing\n" +
                        "RIPV1&2.\n" +
                        "IGRP.\n" +
                        "EIGRP.\n" +
                        "OSPF.\n" +
                        "ISIS.\n" +
                        "BGP.\n" +
                        "Switching\n" +
                        "Introduction.\n" +
                        "VLAN.\n" +
                        "VTP.\n" +
                        "STP.\n" +
                        "RSTP.\n" +
                        "PVST+.\n" +
                        "rapid-PVST+.\n" +
                        "EtherChannel.\n" +
                        "WAN\n" +
                        "Wid Area Network.\n" +
                        "ISDN.\n" +
                        "HDLC & PPP.\n" +
                        "Fram Relay.\n" +
                        "MPLS\n" +
                        "Manage IP Service\n" +
                        "DNS.\n" +
                        "NAT & PAT.\n" +
                        "DHCP.\n" +
                        "CDP.\n" +
                        "VRRP.\n" +
                        "HSRP.\n" +
                        "GLBP.\n" +
                        "Network Management\n" +
                        "IOS management.\n" +
                        "Backup and restore Cisco IOS .\n" +
                        "Password Recovery.\n" +
                        "Telnet.\n" +
                        "Ping and tarceroute.\n" +
                        "SNMP.\n" +
                        "syslog.\n" +
                        "NetFlow.\n" +
                        "Security\n" +
                        "Security Devices.\n" +
                        "VPN.\n" +
                        "Switch Security.\n" +
                        "ACL Standered and Extended.\n" +
                        "IPV6\n" +
                        "IP Network Connectivity.\n" +
                        "Communication type .\n" +
                        "Translation from IPV4 to IP V6.\n" +
                        "IPV6 routing Type.\n" +
                        "VLAN.\n" +
                        "Subnetting.",

                //this content for ccnp course
                ////////////////////////////////////////////////////////////

                "CCNP SWITCH \n" +
                        "\n" +
                        "Module 1: Basic Concepts and Network Design.\n" +
                        "Module 2: Campus Network Architecture.\n" +
                        "Module 3: Spanning Tree Implementation.\n" +
                        "Module 4: Configuring Inter-VLAN Routing.\n" +
                        "Module 5: Implementing High Availability Networks.\n" +
                        "Module 6: First Hop Redundancy Implementation.\n" +
                        "Module 7: Campus Network Security.\n" +
                        "CCNP Routing  \n" +
                        "\n" +
                        "Module 1: Basic Network and Routing Concepts.\n" +
                        "Module 2: EIGRP Implementation.\n" +
                        "Module 3: OSPF Implementation.\n" +
                        "Module 4: Configuration of Redistribution.\n" +
                        "Module 5: Path Control Implementation.\n" +
                        "Module 6: Enterprise Internet Connectivity.\n" +
                        "Module 7: Routers and Routing Protocol Hardening.\n" +
                        "CCNP TShoot \n" +
                        "\n" +
                        "Module 1: Tools and Methodologies of Troubleshooting.\n" +
                        "Module 2: Troubleshooting at SECHNIK Networking Ltd.\n" +
                        "Module 3: Troubleshooting at TINC Garbage Disposal Ltd.\n" +
                        "Module 4: Troubleshooting at PILE Forensic Accounting Ltd.\n" +
                        "Module 5: Troubleshooting at Bank of POLONA Ltd.\n" +
                        "Module 6: Troubleshooting at RADULKO Transport Ltd.",

                //this content for oracle course
                ///////////////////////////////////////////////////////////////////

                "OracleDeveloper(SQL)\n\n" +
                        "Retrieving Data using the SQL SELECT Statement\n" +
                        "\n" +
                        "Restricting and Sorting Data\n" +
                        "\n" +
                        "Using Single-Row Functions to Customize Output\n" +
                        "\n" +
                        "Using Conversion Functions and Conditional Expressions\n" +
                        "\n" +
                        "Reporting Aggregated Data Using the Group Functions\n" +
                        "\n" +
                        "Displaying Data from Multiple Tables Using Joins\n" +
                        "\n" +
                        "Using Subqueries to Solve Queries\n" +
                        "\n" +
                        "Using the SET Operators\n" +
                        "\n" +
                        "Managing Tables using DML statements\n" +
                        "\n" +
                        "Introduction to Data Definition Language\n" +
                        "\n" +
                        "Introduction to Data Dictionary Views\n" +
                        "\n" +
                        "Creating Sequences, Synonyms, Indexes\n" +
                        "\n" +
                        "Creating Views\n" +
                        "\n" +
                        "Managing Schema Objects\n" +
                        "\n" +
                        "Retrieving Data by Using Subqueries\n" +
                        "\n" +
                        "Manipulating Data by Using Subqueries\n" +
                        "\n" +
                        "Controlling User Access\n" +
                        "\n" +
                        "Manipulating Data\n" +
                        "\n" +
                        "Managing Data in Different Time Zones\n\n" +
                        "OracleDeveloper(PL/SQL) \n\n" +
                        "PL/SQL Programming Concepts Review\n" +
                        "\n" +
                        "Designing PL/SQL Code\n" +
                        "\n" +
                        "Using Collections\n" +
                        "\n" +
                        "Manipulating Large Objects\n" +
                        "\n" +
                        "Using Advanced Interface Methods\n" +
                        "\n" +
                        "Performance and Tuning\n" +
                        "\n" +
                        "Improving Performance with Caching\n" +
                        "\n" +
                        "Analyzing PL/SQL Code\n" +
                        "\n" +
                        "Profiling and Tracing PL/SQL Code\n" +
                        "\n" +
                        "Implementing VPD with Fine-Grained Access Control\n" +
                        "\n" +
                        "Safeguarding Your Code Against SQL Injection Attacks\n\n" +
                        "OracleDeveloper(Forms)\n\n" +
                        "Running a Forms Application\n" +
                        "\n" +
                        "Working in the Forms Builder Environment\n" +
                        "\n" +
                        "Creating a Basic Form Module\n" +
                        "\n" +
                        "Creating a Master-Detail Form\n" +
                        "\n" +
                        "Working Data Blocks and Frames\n" +
                        "\n" +
                        "Working with Text Items\n" +
                        "\n" +
                        "Creating LOVs and Editors\n" +
                        "\n" +
                        "Creating Additional Input Items\n" +
                        "\n" +
                        "Creating Noninput Items\n" +
                        "\n" +
                        "Creating Windows and Content Canvases\n" +
                        "\n" +
                        "Working with Other Canvas Types\n" +
                        "\n" +
                        "Producing and Debugging Triggers\n" +
                        "\n" +
                        "Adding Functionality to Items\n" +
                        "\n" +
                        "Displaying Run-Time Messages and Alerts\n" +
                        "\n" +
                        "Using Query Triggers\n" +
                        "\n" +
                        "Validating User Input\n" +
                        "\n" +
                        "Controlling Navigation\n" +
                        "\n" +
                        "Overriding or Supplementing Transaction Processing\n" +
                        "\n" +
                        "Writing Flexible Code\n" +
                        "\n" +
                        "Sharing Objects and Code\n" +
                        "\n" +
                        "Using WebUtil to Interact with the Client\n" +
                        "\n" +
                        "Introducing Multiple Form Applications\n\n" +
                        "OracleDeveloper(Reports)\n\n" +
                        " Introduction to Oracle Reports Developer\n" +
                        "\n" +
                        "Designing and Running Reports\n" +
                        "\n" +
                        "Exploring Oracle Reports Developer\n" +
                        "\n" +
                        "Creating a Paper Report\n" +
                        "\n" +
                        "Enhancing a Basic Paper Report\n" +
                        "\n" +
                        "Managing Report Templates\n" +
                        "\n" +
                        "Creating a Web Report\n" +
                        "\n" +
                        "Enhancing Reports Using the Data Model: Queries and Groups\n" +
                        "\n" +
                        "Enhancing Reports Using the Data Model: Data Sources\n" +
                        "\n" +
                        "Enhancing Reports Using the Data Model: Creating Columns\n" +
                        "\n" +
                        "Enhancing Reports Using the Paper Layout\n" +
                        "\n" +
                        "Controlling the Paper Layout: Common Properties\n" +
                        "\n" +
                        "Controlling the Paper Layout: Specific Properties\n" +
                        "\n" +
                        "Web Reporting\n" +
                        "\n" +
                        "Extending Functionality Using XML\n" +
                        "\n" +
                        "Creating and Using Report Parameters\n" +
                        "\n" +
                        "Embedding a Graph in a Report\n" +
                        "\n" +
                        "Enhancing Matrix Reports\n" +
                        "\n" +
                        "Coding PL/SQL Triggers\n" +
                        "\n" +
                        "Extending Functionality Using the SRW Package\n" +
                        "\n" +
                        "Maximizing Performance Using OracleAS Reports Services\n" +
                        "\n" +
                        "Building Reports: Efficiency Guidelines.",

                //this content for Adf course
                ////////////////////////////////////////////////////////////////

                "Part 1: Concept Java SE\n\n" +
                        "Introduction and Overview Control Structure\n" +
                        "Datatypes\n" +
                        "If, if-else statements\n" +
                        "While loop\n" +
                        "Do while loop\n" +
                        "For & foreach loop\n" +
                        "Arrays\n" +
                        "Arrays\n" +
                        "String\n" +
                        "OOP\n" +
                        "Overview about traditional programming,\n" +
                        "Access Modifiers,\n" +
                        "Introduction to classes and methods,\n" +
                        "Introduction to object oriented programming\n" +
                        "Encapsulation\n" +
                        "Inheritance\n" +
                        "Polymorphism\n" +
                        "Abstraction\n" +
                        "Interfaces\n\n" +
                        "Part 2: Concept Java 2EE\n\n" +
                        "Introduction to servlet\n" +
                        "Introduction to Application Server\n" +
                        "Servlet life cycle methods\n" +
                        "Accessing servlet environment variables\n" +
                        "Adding text fields and drop-down lists\n" +
                        "Retrieving form data in the servlet\n" +
                        "Accessing Databases with Servelets\n" +
                        "Connecting to the database.\n" +
                        "Submitting SQL statements\n" +
                        "Retrieving and processing data\n\n" +
                        "Part 3: Concept SQL\n\n" +
                        "Data Manipulation Language\n" +
                        "DML Statements\n" +
                        "The SELECT Statement\n" +
                        "The INSERT Statement\n" +
                        "The DELETE Statement\n" +
                        "The UPDATE Statement\n" +
                        "More SQL*Plus Commands\n" +
                        "SQL FUNCTIONS\n" +
                        "Introduction\n" +
                        "The DISTINCT Keyword\n" +
                        "Aliases\n" +
                        "Miscellaneous Functions\n" +
                        "Mathematical Functions\n" +
                        "String Functions\n" +
                        "Date Functions\n" +
                        "Conversion Functions\n" +
                        "Pseudo Columns\n" +
                        "Groups\n" +
                        "SQL Statements\n" +
                        "GROUP BY Clause\n" +
                        "HAVING Clause\n" +
                        "Order of a SELECT Statement\n" +
                        "SQL Operators\n" +
                        "Simple Selects\n" +
                        "Comparison Operators\n" +
                        "IN and NOT IN Operators\n" +
                        "BETWEEN Operator\n" +
                        "The LIKE Operator\n" +
                        "Logical Operators\n" +
                        "IS NULL and IS NOT NULL\n" +
                        "ANY\n" +
                        "ALL\n" +
                        "Joining Tables\n" +
                        "Joins\n" +
                        "Cartesian Product\n" +
                        "Inner Joins\n" +
                        "Equi-Join\n" +
                        "Table Aliases\n" +
                        "Non-Equi Join\n" +
                        "Non-Key Join\n" +
                        "Reflexive Join\n" +
                        "Natural Join\n" +
                        "Outer Joins\n" +
                        "Right Outer Join\n" +
                        "Left Outer Join\n" +
                        "Full Outer Join\n" +
                        "Oracle-Specific Syntax for Outer Joins\n" +
                        "Data Definition Language\n" +
                        "Categories of SQL Statements\n" +
                        "Oracle Datatypes\n" +
                        "The CREATE Statement\n" +
                        "The DROP Command\n" +
                        "The ALTER Command\n" +
                        "Integrity Constraints\n" +
                        "Entity Integrity Constraints\n" +
                        "Referential Integrity Constraints\n" +
                        "Modifying Table to Use Constraints\n" +
                        "Checking Constraints\n" +
                        "The Data Dictionary\n\n" +
                        "Part 4: Oracle ADF\n\n" +
                        "Introduction to Fusion and ADF\n" +
                        "Oracle ADF and JDeveloper\n" +
                        "Oracle Fusion Middleware\n" +
                        "Oracle Fusion Architecture\n" +
                        "ADF and MVC\n" +
                        "More about ADF\n" +
                        "JDeveloper 11g New Features\n" +
                        "Building ADF Application in JDeveloper\n" +
                        "Configuring JDeveloper Preferences\n" +
                        "Database Schema Design\n" +
                        "JDeveloper 11g New Features\n" +
                        "Database Designing Tools in JDeveloper\n" +
                        "Creating Offline Objects\n" +
                        "Synchronize Online-Offline Database\n" +
                        "Data Modeling with ADF Business Components\n" +
                        "Advantages of ADF BC\n" +
                        "ADF BC Categories\n" +
                        "Creating ADF Business Components\n" +
                        "Business Component Browser\n" +
                        "Entity Objects and Associations\n" +
                        "Data Persistence using Entity Objects\n" +
                        "Creating Entity Objects\n" +
                        "Modify Entity Object Default Behavior\n" +
                        "Associations\n" +
                        "View Objects and View Links\n" +
                        "Populating Data in View Objects\n" +
                        "Creating View Objects\n" +
                        "Modify View Object Default Behavior\n" +
                        "View Links\n" +
                        "Creating View Criteria\n" +
                        "Creating List of Values\n" +
                        "Application Modules\n" +
                        "Designing Application Module\n" +
                        "Creating Application Module\n" +
                        "Application Module Editor\n" +
                        "Testing Service Methods\n" +
                        "Programmatically Modifying Default Behavior\n" +
                        "Supporting Java Classes\n" +
                        "Modify Entity Object Behavior\n" +
                        "Modify View Object Behavior\n" +
                        "Service Methods and Application Module\n" +
                        "Business Validation\n" +
                        "Validation Life Cycle\n" +
                        "Built-in Declarative Validation Rules\n" +
                        "Validation Execution\n" +
                        "Failure Handling\n" +
                        "Groovy Support\n" +
                        "Creating Validation Rule Class\n" +
                        "Introduction to User Interface Technologies\n" +
                        "User Interface – Available Technologies\n" +
                        "Java Server Faces\n" +
                        "ADF Faces\n" +
                        "Understanding ADF Data bindings\n" +
                        "ADF Data Model and Bindings\n" +
                        "Exposing Business Components as Data Controls\n" +
                        "JSF Expression Language\n" +
                        "Binding Components to Data\n" +
                        "Understanding ADF Task Flows\n" +
                        "Characteristics of ADF Task Flow\n" +
                        "Creating a Task Flow\n" +
                        "Using ADF Task Flow Components\n" +
                        "Using Method Call Activities\n" +
                        "Creating Managed Beans\n" +
                        "Enriching the Page Content\n" +
                        "ADF Faces Rich Client Components\n" +
                        "Using Facets\n" +
                        "Using ADF Faces Components\n" +
                        "UI and Translation\n" +
                        "Understanding Layout Basics\n" +
                        "ADF Faces Layout Components\n" +
                        "ADF Faces Skins\n" +
                        "Enabling PPR\n" +
                        "Ensuring Reusability\n" +
                        "Pros and Cons of Reusability\n" +
                        "Reusing Components\n" +
                        "Designing for Reuse\n" +
                        "Creating ADF Library\n" +
                        "What Fits your Requirements\n" +
                        "Implementing Page Navigation\n" +
                        "ADF Faces Navigation Components\n" +
                        "Performing Navigation\n" +
                        "Defining Access Keys\n" +
                        "Using Train Components\n" +
                        "Handling Application Events\n" +
                        "JSF Page Life Cycle\n" +
                        "ADF Lifecycle Phases\n" +
                        "Creating Action Methods\n" +
                        "Value Change Events\n" +
                        "Managing and Validating Data\n" +
                        "Holding Values in Data Model\n" +
                        "Holding Values in Managed Beans\n" +
                        "Passing Values between Pages\n" +
                        "Validation Event Points\n" +
                        "ADF Binding Validation\n" +
                        "ADF Faces Validation.",

                //this content for webdesign coures
                /////////////////////////////////////////////////////////////

                "Intro to web fundamentals\n" +
                        "Intro for Hyper Text Markup Language\n" +
                        "Understanding the web page structure\n" +
                        "How pages are executed and compiled?\n" +
                        "What the component of web pages\n" +
                        "HTML4\n" +
                        "Study the Tags of HTML4\n" +
                        "How to make good design page using HTML4\n" +
                        "HTML5\n" +
                        "Study removed tags in HTML4\n" +
                        "Study new tags in HTML5\n" +
                        "Building full structured web page using HTML4 and HTML5\n" +
                        "CSS2\n" +
                        "Study the difference between CSS [Cascading Style Sheets] and HTML\n" +
                        "The structure of CSS code\n" +
                        "How to link between HTML and CSS\n" +
                        "Study the selectors and what are their priorities\n" +
                        "Study the formatting and values of each priorities\n" +
                        "CSS3\n" +
                        "Study removed properties in CSS2\n" +
                        "Study new properties in CSS3\n" +
                        "Building full well designed web pages using HTML4, HTML5, CSS2 and CSS3\n" +
                        "PSD to HTML\n" +
                        "Understand the basics of Photoshop\n" +
                        "How you can get a free PSD template\n" +
                        "Study the principles, you should follow to convert PSD image to HTML code\n" +
                        "Workshop with converting a PSD to website\n" +
                        "JavaScript\n" +
                        "Study the principles of programming\n" +
                        "Variables\n" +
                        "Loops\n" +
                        "Conditional statements\n" +
                        "Understand DOM\n" +
                        "How to design and animate page using JavaScript\n" +
                        "How to build a plugin from scratch\n" +
                        "JQuery\n" +
                        "What and why is JQuery?\n" +
                        "The slogan of JQuery\n" +
                        "How to use JQuery\n" +
                        "What is the CDN?\n" +
                        "Study the main functions of JQuery library to animate your page\n" +
                        "How to build a plugin\n" +
                        "How to use ready plugins, how to get it and how to edit or customize it?\n" +
                        "Bootstrap\n" +
                        "Understand the concepts of responsive design\n" +
                        "Why should use bootstrap?\n" +
                        "How to build first web page using bootstrap?\n" +
                        "Understanding the grid system\n" +
                        "Study the classes of bootstrap and how to use its documentation?\n" +
                        "Project\n" +
                        "Building a web site that fits all screen devices\n" +
                        "Using all learnt technologies\n" +
                        "Workshop\n" +
                        "full day in IT Sharks, Implemting real projects as like as in a company",

                //this content for object orinted course
                /////////////////////////////////////////////////////////////

                "Introduction \n" +
                        "\n" +
                        "Introduction.\n" +
                        "OOP History.\n" +
                        "Main OOP Concepts.\n" +
                        "Abstract Data types.\n" +
                        "Mapping real world objects.\n" +
                        "Classes And Objects\n" +
                        "\n" +
                        "Class Definitions, Define Objects.\n" +
                        "Accessing the Class Members.\n" +
                        "Member Functions and Data Members.\n" +
                        "Access specifiers.\n" +
                        "Constructors with Default Arguments.\n" +
                        " Data Abstraction And Encapsulation\n" +
                        "\n" +
                        "Benefits of Data Abstraction.\n" +
                        "Data Encapsulation.\n" +
                        "Separating Interface from Implementation.\n" +
                        "friend Functions and friend Classes.\n" +
                        "Using the this Pointer.\n" +
                        "Dynamic Memory Management with Operators new and delete.\n" +
                        "Inheritance \n" +
                        "\n" +
                        "Base & Derived Classes. \n" +
                        "Access Control and Inheritance.\n" +
                        "Type of Inheritance. \n" +
                        "Multiple Inheritances.\n" +
                        "Relationship between Base Classes and Derived Classes.\n" +
                        "Constructors and Destructors in Derived Classes.\n" +
                        "Classes Relations \n" +
                        "\n" +
                        "Association.\n" +
                        "Aggregation.\n" +
                        "Composition.\n" +
                        "Overloading(Operator And Function) \n" +
                        "\n" +
                        "Function overloading.\n" +
                        "Operators overloading.\n" +
                        "Overloadable/Non-overloadable Operators. \n" +
                        "Polymorphism \n" +
                        "\n" +
                        "Polymorphism Concept.\n" +
                        "Virtual Function.\n" +
                        "Pure Virtual Functions.\n" +
                        "Abstract Class.\n" +
                        "Project \n" +
                        "\n" +
                        "Practical project.\n" +
                        "Group of 2-3 persons select an idea.\n" +
                        "Register in Object Oriented Programming (OOP).",

                //this content for data strucure course
                /////////////////////////////////////////////////

                "Module One: Data Structure Basics \n" +
                        "\n" +
                        "General discussion on programming principles and software engineering Ch. 1,2.\n" +
                        "The importance of Data Structures will be motivated. HW: big program involving files.\n" +
                        "Growth of functions.\n" +
                        "Complexity: Sec. 3.2, 3.3 from Rosen.\n" +
                        "Module Two: Stack\n" +
                        "\n" +
                        "The concept of ADT and Stacks: contiguous implementation. (Ch. 3). \n" +
                        "Stacks: linked implementation. (Ch.3).\n" +
                        "Module Three: Recursion \n" +
                        "\n" +
                        "Recursion, Recursion vs. iteration, tail recursion, unnecessarily recursion (Ch. 3). \n" +
                        "Module Four: Queues \n" +
                        "\n" +
                        "More on ADT and queues (contiguous implementation) Ch. 4. \n" +
                        "Queues: linked implementation. \n" +
                        "General lists: contiguous implementation. Ch. 4, Ch. 5.\n" +
                        "Module Five: Lists \n" +
                        "\n" +
                        "General lists: linked implementation.\n" +
                        "Sequential search Ch.5, Ch.6.\n" +
                        "Module Six: Binary Search And Tree\n" +
                        "\n" +
                        "Binary search Ch. 6. \n" +
                        "Some tree terminology and rigorous analysis of Binary search, and proving important theorems.\n" +
                        "Trees and BST Ch. 9.\n" +
                        "BST (cont.) including deleting nodes. \n" +
                        "Graph representation and Breadth first and depth first traversal.\n" +
                        "Module Seven: Project \n" +
                        "\n" +
                        "Group of 2-3 persons select an idea. \n" +
                        "The lecturer discusses the code with you.\n" +
                        "Guide you to reach for the best practical project.",

                //this content for python course
                ///////////////////////////////////////////////////////////
                "Introduction and Overview \n" +
                        "\n" +
                        "Introduction to stand-alone application\n" +
                        "Overview about Python applications\n" +
                        "overview about libraries\n" +
                        "Declaring and initializing variables\n" +
                        "How to print in Console\n" +
                        "How to scan values from user\n" +
                        "Control Structure and Dictionaries\n" +
                        "\n" +
                        "If, if-else statements\n" +
                        "While loop\n" +
                        "Foreach loop\n" +
                        "Switch statement\n" +
                        "Introduction to  Dialogs and message boxes.\n" +
                        "Built-in Functions\n" +
                        "Sets\n" +
                        "Dictionaries\n" +
                        "Inverting a Dictionary\n" +
                        "Lists And Strings\n" +
                        "\n" +
                        "Lists and Indices\n" +
                        "Modifying Lists\n" +
                        "Built-in Functions on Lists\n" +
                        "Processing List Items\n" +
                        "Slicing\n" +
                        "Aliasing\n" +
                        "Strings\n" +
                        "OOP \n" +
                        "\n" +
                        "Overview about traditional programming,\n" +
                        "Introduction to classes and methods.\n" +
                        "Introduction to object oriented programming\n" +
                        "Encapsulation\n" +
                        "Inheritance\n" +
                        "GUI\n" +
                        "\n" +
                        "Introduction to Graphics User Interface,\n" +
                        "Tkinter Module\n" +
                        "Basic GUI Construction\n" +
                        "Models, Views, and Controllers\n" +
                        "Style\n" +
                        "SQL \n" +
                        "\n" +
                        "Introduction to SQL,\n" +
                        "Submitting SQL statements,\n" +
                        "Retrieving and processing results.\n" +
                        "Python MySQldb\n" +
                        "\n" +
                        "Introduction to MySQl\n" +
                        "Connecting to a database.\n" +
                        "Retrieving Data\n" +
                        "Updating and Deleting\n" +
                        "Transactions\n" +
                        "Application Using MySQldb \n" +
                        "\n" +
                        "Implementing application using MySQldb\n" +
                        "Storing and Retrieving Data with File I/O\n" +
                        "\n" +
                        "Reading and writing files.\n" +
                        "Creating, deleting and renaming files.\n" +
                        "Obtaining directory and file information.\n" +
                        "Handling exceptions with try and except.\n" +
                        "Project \n" +
                        "\n" +
                        "Project In windows Form \n" +
                        "Group of 2-3 persons select an idea.\n" +
                        "The lecturer discusses the code with you.",

                //this content for oracle adminstration course
                ////////////////////////////////////////////////////////////

                "OracleAdministration(SQL)\n\n" +
                        "Retrieving Data using the SQL SELECT Statement\n" +
                        "\n" +
                        "Restricting and Sorting Data\n" +
                        "\n" +
                        "Using Single-Row Functions to Customize Output\n" +
                        "\n" +
                        "Using Conversion Functions and Conditional Expressions\n" +
                        "\n" +
                        "Reporting Aggregated Data Using the Group Functions\n" +
                        "\n" +
                        "Displaying Data from Multiple Tables Using Joins\n" +
                        "\n" +
                        "Using Subqueries to Solve Queries\n" +
                        "\n" +
                        "Using the SET Operators\n" +
                        "\n" +
                        "Managing Tables using DML statements\n" +
                        "\n" +
                        "Introduction to Data Definition Language\n" +
                        "\n" +
                        "Introduction to Data Dictionary Views\n" +
                        "\n" +
                        "Creating Sequences, Synonyms, Indexes\n" +
                        "\n" +
                        "Creating Views\n" +
                        "\n" +
                        "Managing Schema Objects\n" +
                        "\n" +
                        "Retrieving Data by Using Subqueries\n" +
                        "\n" +
                        "Manipulating Data by Using Subqueries\n" +
                        "\n" +
                        "Controlling User Access\n" +
                        "\n" +
                        "Manipulating Data\n" +
                        "\n" +
                        "Managing Data in Different Time Zones\n\n" +
                        "OracleAdministration(Workshop 1)\n\n" +
                        "Oracle Database 11g Release 2: Database Architecture and Recovery Operations\n" +
                        "\n" +
                        "Oracle Database 11g Release 2: The RMAN Catalog and Creating Backups\n" +
                        "\n" +
                        "Oracle Database 11g Release 2: Performing Restore and Recovery Tasks\n" +
                        "\n" +
                        "Oracle Database 11g Release 2: Using, Monitoring and Tuning RMAN\n" +
                        "\n" +
                        "Oracle Database 11g Release 2: Database Diagnostics and Flashback Technologies\n" +
                        "\n" +
                        "Oracle Database 11g Release 2: Managing Database Memory and Performance\n" +
                        "\n" +
                        "Oracle Database 11g Release 2: Managing Database Resources and the Scheduler\n" +
                        "\n" +
                        "Oracle Database 11g Release 2: Managing Database Space and Duplication\n\n" +
                        "OracleAdministration(Workshop 2)\n\n" +
                        "Exploring the Oracle Database Architecture\n" +
                        "\n" +
                        "Installing your Oracle Software\n" +
                        "\n" +
                        "Creating an Oracle Database\n" +
                        "\n" +
                        "Managing the Oracle Database Instance\n" +
                        "\n" +
                        "Manage the ASM Instance\n" +
                        "\n" +
                        "Configuring the Oracle Network Environment\n" +
                        "\n" +
                        "Managing Database Storage Structures\n" +
                        "\n" +
                        "Administering User Security\n" +
                        "\n" +
                        "Managing Data Concurrency\n" +
                        "\n" +
                        "Managing Undo Data\n" +
                        "\n" +
                        "Implementing Oracle Database Auditing\n" +
                        "\n" +
                        "Database Maintenance\n" +
                        "\n" +
                        "Performance Management\n" +
                        "\n" +
                        "Backup and Recovery Concepts\n" +
                        "\n" +
                        "Performing Database Backups\n" +
                        "\n" +
                        "Performing Database Recovery\n" +
                        "\n" +
                        "Moving Data\n" +
                        "\n" +
                        "Working with Support."
        };

        //this content values array which carry all data of course table
        ContentValues[] courseValues = new ContentValues[courseNames.length];
        for (int i = 0; i < courseValues.length; i++) {
            courseValues[i] = new ContentValues();
            courseValues[i].put(Contract.CourseTable.NAME, courseNames[i]);
            courseValues[i].put(Contract.CourseTable.NO_OF_WEEKS, courseWeeks[i]);
            courseValues[i].put(Contract.CourseTable.NO_OF_HOURS, courseHours[i]);
            courseValues[i].put(Contract.CourseTable.CONTENT, courseContent[i]);
            courseValues[i].put(Contract.CourseTable.IMAGE, courseImages[i]);
        }

        //these all data for constructor table
        int[] instructorImages = new int[]{
                R.drawable.ahmedshaaban,
                R.drawable.mahmoud,
                R.drawable.abdo,
                R.drawable.reham,
                R.drawable.mahmoudjava,
                R.drawable.eslam,
                R.drawable.mohamed,
                R.drawable.ahmed,
                R.drawable.elzeiny,
                R.drawable.khaled,
                R.drawable.mohammed
        };
        String[] instructorNames = new String[]{
                "Ahmed Shaaaban Elgendy",
                "Mahmoud Ahmed Elsafty",
                "Abdel-Aziz Aboul-Soud",
                "Reham mokhtar mohamed",
                "Muhammed Sweelam",
                "Eslam Yousuf",
                "Mohamed Faesal",
                "Ahmed Nasser",
                "Ahmed Salem Elzeiny",
                "Khaled Nemer",
                "Mohamed Ashraf"
        };
        String[] instructorsCourses = new String[]{
                "Php Course",
                "asp.net Diploma",
                "Oralce Financial Course",
                "Android Diploma",
                "Full Java Diploma",
                "Full Java Diploma",
                "Course C/C++",
                "Web Design Course",
                "Android Diploma",
                "Full Java Diploma",
                "PHP-Diploma"
        };

        //this content values array which carry all data of instructor table
        ContentValues[] instructorValues = new ContentValues[instructorNames.length];
        for (int i = 0; i < instructorValues.length; i++) {
            instructorValues[i] = new ContentValues();
            instructorValues[i].put(Contract.InstructorTable.NAME, instructorNames[i]);
            instructorValues[i].put(Contract.InstructorTable.COURSE, instructorsCourses[i]);
            instructorValues[i].put(Contract.InstructorTable.IMAGE, instructorImages[i]);
        }
        bulkInsert(db, Contract.CourseTable.TABLE_NAME, courseValues);
        bulkInsert(db, Contract.InstructorTable.TABLE_NAME, instructorValues);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Contract.CourseTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + Contract.ReviewTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + Contract.InstructorTable.TABLE_NAME);
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" + Contract.CourseTable.TABLE_NAME + "'");
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" + Contract.InstructorTable.TABLE_NAME + "'");
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" + Contract.ReviewTable.TABLE_NAME + "'");
        onCreate(db);
    }

    /*
    this method which insert bulk of data (instructor , course)
    i used SQLite insert here because there no benefit to use content provider at Data source class
     */
    public int bulkInsert(SQLiteDatabase db, String tableName, ContentValues[] values) {
        int numberOfInserted;
        db.beginTransaction();
        try {
            for (ContentValues value : values) {
                long _id = db.insertOrThrow(tableName, null, value);
                if (_id <= 0) {
                    throw new SQLException("Failed To insert row");
                }
            }
            db.setTransactionSuccessful();
            numberOfInserted = values.length;
        } finally {
            db.endTransaction();
        }
        return numberOfInserted;
    }

    //Note that :-
    /*
        i make these data fixed and if the developer want to edit in a specific content of data
        he `ll makes all changes he want and increase the databaseVersion.
        that`s because the updates is infrequently and small (almost every 2 years or more)
     */
}
