package aboalarbe.app.com.itsharks.Sync;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.AbstractThreadedSyncAdapter;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SyncResult;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import aboalarbe.app.com.itsharks.Data.Contract;
import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Utilities.ReviewObject;

import static android.content.Context.ACCOUNT_SERVICE;

/**
 * Created by mohamed_aboalarbe on 6/2/2017.
 */

public class SyncAdapter extends AbstractThreadedSyncAdapter {

    private Context context;

    public SyncAdapter(Context context, boolean autoInitialize) {
        super(context, autoInitialize);
        this.context = context;
    }

    public SyncAdapter(Context context, boolean autoInitialize, boolean parallelSync) {
        super(context, autoInitialize, parallelSync);
        this.context = context;
    }

    @Override
    public void onPerformSync(Account account, Bundle extras, String authority, ContentProviderClient provider, SyncResult syncResult) {
        getReviewFromServer(context);
    }

    /*
    this method create dummy account because the server dosen`t request account authenticator
     */
    public static Account getSyncAccount(Context context) {
        Account newAccount = new Account(
                context.getString(R.string.it_sharks), context.getString(R.string.account_type));
        AccountManager accountManager =
                (AccountManager) context.getSystemService(
                        ACCOUNT_SERVICE);
        return newAccount;
    }

    /*
    this method which request data from server immediatley
     */
    public static void syncImmediately(Context context) {
        Bundle bundle = new Bundle();
        bundle.putBoolean(ContentResolver.SYNC_EXTRAS_EXPEDITED, true);
        bundle.putBoolean(ContentResolver.SYNC_EXTRAS_MANUAL, true);
        ContentResolver.requestSync(getSyncAccount(context),
                context.getString(R.string.authority), bundle);
    }

    /*
    this method resolve the server to get the reviews as json objects
     */
    public static void getReviewFromServer(final Context context) {
        RequestQueue queue = Volley.newRequestQueue(context);
        String serverUrl = context.getString(R.string.server_url_get_review);
        StringRequest request = new StringRequest(Request.Method.POST, serverUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                insertReviewData(context, response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, context.getString(R.string.unexcepected_error), Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(request);
    }

    /*
    this method which parsing the json data which get from the sever
     */
    private static ArrayList<ReviewObject> parseJsonReviewData(Context context, String response) {
        ArrayList<ReviewObject> list = new ArrayList<ReviewObject>();
        JSONObject object = null;
        try {
            object = new JSONObject(response);
            JSONArray arr = object.getJSONArray(context.getString(R.string.json_array_key));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String studentName = obj.getString(context.getString(R.string.student_name_key));
                String courseName = obj.getString(context.getString(R.string.course_name_key));
                String review = obj.getString(context.getString(R.string.review_key));
                String reviewDate = obj.getString(context.getString(R.string.date_key));
                String userImageUrl = obj.getString(context.getString(R.string.user_image_key));
                list.add(new ReviewObject(studentName, courseName, review, reviewDate, userImageUrl));
            }
            return list;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    /*
    this method that insert the data which get from the server into the database for caching
     */
    private static void insertReviewData(Context context, String response) {
        ArrayList<ReviewObject> list = parseJsonReviewData(context, response);
        ContentValues[] values = new ContentValues[list.size()];
        for (int i = 0; i < values.length; i++) {
            values[i] = new ContentValues();
            values[i].put(Contract.ReviewTable.STUDENT_NAME, list.get(i).getStudentName());
            values[i].put(Contract.ReviewTable.COURSENAME, list.get(i).getReview_course());
            values[i].put(Contract.ReviewTable.STUDENT_REVIEW, list.get(i).getReviewContent());
            values[i].put(Contract.ReviewTable.DATE_OF_REVIEW, list.get(i).getReviewDate());
            values[i].put(Contract.ReviewTable.USER_IMAGE, list.get(i).getUserImage());
        }
        context.getContentResolver().bulkInsert(Contract.ReviewTable.CONTENT_URI, values);
    }
}
