package aboalarbe.app.com.itsharks.Utilities;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by mohamed_aboalarbe on 5/14/2017.
 */

public class CourseObject implements Parcelable {
    private String courseName;
    private String no_weeks;
    private String no_hours;
    private String courseContent;
    private int courseImage;

    public CourseObject(String courseName, String no_weeks, String no_hours, String courseContent, int courseImage) {
        this.courseName = courseName;
        this.no_weeks = no_weeks;
        this.no_hours = no_hours;
        this.courseContent = courseContent;
        this.courseImage = courseImage;
    }

    protected CourseObject(Parcel in) {
        courseName = in.readString();
        no_weeks = in.readString();
        no_hours = in.readString();
        courseContent = in.readString();
        courseImage = in.readInt();
    }

    public static final Creator<CourseObject> CREATOR = new Creator<CourseObject>() {
        @Override
        public CourseObject createFromParcel(Parcel in) {
            return new CourseObject(in);
        }

        @Override
        public CourseObject[] newArray(int size) {
            return new CourseObject[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(courseName);
        dest.writeString(no_weeks);
        dest.writeString(no_hours);
        dest.writeString(courseContent);
        dest.writeInt(courseImage);
    }

    public String getCourseName() {
        return courseName;
    }

    public String getNo_weeks() {
        return no_weeks;
    }

    public String getNo_hours() {
        return no_hours;
    }

    public String getCourseContent() {
        return courseContent;
    }

    public int getCourseImage() {
        return courseImage;
    }
}
