package aboalarbe.app.com.itsharks.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import aboalarbe.app.com.itsharks.Ui.AddReviewFragment;
import aboalarbe.app.com.itsharks.Ui.DisplayReviewFragment;

/**
 * Created by mohamed_aboalarbe on 5/23/2017.
 */

public class ReviewAdapter extends FragmentStatePagerAdapter {

    private int num_tabs;

    public ReviewAdapter(FragmentManager fm, int num_tabs) {
        super(fm);
        this.num_tabs = num_tabs;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new AddReviewFragment();
            case 1:
                return new DisplayReviewFragment();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return num_tabs;
    }
}
