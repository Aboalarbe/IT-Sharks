package aboalarbe.app.com.itsharks.Utilities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.view.Menu;
import android.view.View;

import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.auth.ErrorCodes;
import com.firebase.ui.auth.IdpResponse;
import com.firebase.ui.auth.ResultCodes;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Arrays;

import aboalarbe.app.com.itsharks.BuildConfig;
import aboalarbe.app.com.itsharks.R;
import aboalarbe.app.com.itsharks.Ui.Course;

/**
 * Created by mohamed_aboalarbe on 5/24/2017.
 */

public class Authentication {
    /*
    this method check the user state (login / logout)
     */
    public static boolean isAlreadySigned(FirebaseAuth auth) {
        if (auth.getCurrentUser() != null) {
            return true;
        } else {
            return false;
        }
    }

    /*
    this method start the Ui flow for Authentication process
     */
    public static void startSigninUiFlow(Activity activity, int RC_SIGN_IN) {
        activity.startActivityForResult(
                // Get an instance of AuthUI based on the default app
                AuthUI.getInstance()
                        .createSignInIntentBuilder()
                        .setProviders(Arrays.asList(
                                new AuthUI.IdpConfig.Builder(AuthUI.EMAIL_PROVIDER).build(),
                                new AuthUI.IdpConfig.Builder(AuthUI.GOOGLE_PROVIDER).build(),
                                new AuthUI.IdpConfig.Builder(AuthUI.FACEBOOK_PROVIDER).build()))
                        .setIsSmartLockEnabled(false)
                        .setTheme(R.style.AppTheme)
                        .setLogo(R.drawable.logo)
                        .build(),
                RC_SIGN_IN);
    }

    /*
    this method match the result codes that returned from the authentication process
     */
    public static void matchResultCodes(Context context, int requestCode, int resultCode, Intent data, int RC_SIGN_IN, View view) {
        if (requestCode == RC_SIGN_IN) {
            IdpResponse response = IdpResponse.fromResultIntent(data);

            // Successfully signed in
            if (resultCode == ResultCodes.OK) {
                showSnackbar(view, context.getString(R.string.auth_done));
                return;
            } else {
                // Sign in failed
                if (response == null) {
                    // User pressed back button
                    showSnackbar(view, context.getString(R.string.auth_canceled));
                    return;
                }

                if (response.getErrorCode() == ErrorCodes.NO_NETWORK) {
                    showSnackbar(view, context.getString(R.string.auth_no_internet));
                    return;
                }

                if (response.getErrorCode() == ErrorCodes.UNKNOWN_ERROR) {
                    showSnackbar(view, context.getString(R.string.auth_unknown_error));
                    return;
                }
            }

            showSnackbar(view, context.getString(R.string.auth_unknown_response));
        }
    }

    /*
    this method signed out the user
     */
    public static void signOut(final Activity activity, final View view) {
        AuthUI.getInstance()
                .signOut(activity)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        activity.startActivity(new Intent(activity, Course.class));
                        activity.finish();
                        showSnackbar(view, activity.getString(R.string.logOut_done));
                    }
                });
    }

    /*
    this method is responsible for displaying snackbar messages in the app
     */
    public static void showSnackbar(View view, String message) {
        Snackbar.make(view, message, Snackbar.LENGTH_LONG).show();
    }

    /*
    this method toggle the user login state (login/logout) in the navigation drawer
     */
    public static void showLoginStateItem(NavigationView view, String state) {
        Menu navMenu = view.getMenu();
        navMenu.findItem(R.id.nav_account).setTitle(state);
    }

    /*
    this method display profile icon in Navigation drawer when user login
     */
    public static void showProfileItem(NavigationView view) {
        Menu navMenu = view.getMenu();
        navMenu.findItem(R.id.nav_profile).setVisible(true);
    }

    /*
    this method hide profile icon in Navigation drawer when user logout
     */
    public static void hideProfileItem(NavigationView view) {
        Menu navMenu = view.getMenu();
        navMenu.findItem(R.id.nav_profile).setVisible(false);
    }
}

/*
Note that :-
any user can use the app without sign up but there is Restrictions on the reviews
because i want only the users which sign up to sent and see reviews.
 */

/*
Note that :-
for ethics i implemented the authentication process using this tutorial
on github "https://github.com/firebase/FirebaseUI-Android/tree/master/auth#configuration"
and customize on my app.
 */