<?php
$conn =mysqli_connect('localhost','id1917149_itsharks','00000000','id1917149_itsharks');
if(!$conn)
{
	die("coneection Error".mysqli_error());
}
if(function_exists($_GET['f']))
{
	$_GET['f']();
}
function sendStudentData(){
	global $conn;
	$f_name=$_POST['firstName'];
	$l_name=$_POST['lastName'];
	$phone=$_POST['phoneNumber'];
	$email=$_POST['email'];
	$facebook=$_POST['facebook'];
	$course_name=$_POST['courseName'];
	$query="insert into student_data (first_name,last_name,phone_number,email,facebook,course_name)values('$f_name','$l_name','$phone','$email','$facebook','$course_name');";
	$result=mysqli_query($conn,$query);
	if($result)
	{
		$response=array("response"=>"done");
		echo json_encode($response);
	
	}
	else
	{
		$response=array("response"=>"not done !");
		echo json_encode($response);
	}
}

function sendReviewData(){
	global $conn;
	$s_name=$_POST['studentName'];
	$c_name=$_POST['courseName'];
	$feedback=$_POST['feedback'];
	$date=$_POST['date'];
	$image_url=$_POST['imageUrl'];
	$query="insert into review (studentname,coursename,reviewcontent,reviewdate,userimage)values('$s_name','$c_name','$feedback','$date','$image_url');";
	$result=mysqli_query($conn,$query);
	if($result)
	{
		$response=array("response"=>"done");
		echo json_encode($response);
	
	}
	else
	{
		$response=array("response"=>"not done !");
		echo json_encode($response);
	}
}
function getReviewData()
	{
		global $conn;
		$query="select * from review;"; 
		$result=mysqli_query($conn,$query);
		$row=mysqli_num_rows($result);
		if($row>0)
		{
			$arr["list"]=array();
				while($temp=mysqli_fetch_assoc($result))
				{
					$student_name=$temp['studentname'];
                    $course_name=$temp['coursename'];
                    $review_cont=$temp['reviewcontent'];
					$review_date=$temp['reviewdate'];
					$user_photo=$temp['userimage'];
				    $response1=array("studentName"=>$student_name,"courseName"=>$course_name,"review"=>$review_cont,"date"=>$review_date,"imageUrl"=>$user_photo);
					array_push($arr["list"],$response1);
				}
				 echo json_encode($arr);
		}
	}
?>